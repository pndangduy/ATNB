namespace DAO.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Helicopter")]
    public partial class Helicopter
    {
        [Key]
        [StringLength(7)]
        public string HelecopterID { get; set; }

        [Required]
        [StringLength(40)]
        public string Model { get; set; }

        public double? CruiseSpeed { get; set; }

        public double? EmptyWeight { get; set; }

        public double? MaxTakeOffWeight { get; set; }

        public double? Rang { get; set; }

        public int? FlyMethod { get; set; }

        [StringLength(7)]
        public string AirPortID { get; set; }

        public bool IsActive { get; set; }

        public virtual AirPort AirPort { get; set; }
    }
}
