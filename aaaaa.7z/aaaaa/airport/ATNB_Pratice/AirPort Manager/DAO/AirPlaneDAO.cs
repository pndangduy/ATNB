﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;

namespace DAO
{
    public class AirPlaneDAO
    {
        EF.AirportDbContext db;
        public AirPlaneDAO()
        {
            db = new EF.AirportDbContext();
        }



        // Add
        public string Add(AirPlane airplane)
        {
            try
            {
                EF.AirPlane entity = new EF.AirPlane();

                entity.AirplaneId = airplane.PlaneID;
                entity.Model = airplane.Model;
                entity.CruiseSpeed = airplane.CruiseSpeed;
                entity.EmptyWeight = airplane.EmptyWeight;
                entity.MaxTakeOffWeight = airplane.MaxTakeOffWeight;
                entity.FlyMethod = airplane.FlyMethod;
                entity.AirplaneTypeID = airplane.AirPlaneTypeID;
                entity.MinRunWay = airplane.MinRunWay;

                db.AirPlanes.Add(entity);
                db.SaveChanges();
                return entity.AirplaneId;
            }
            catch
            {
                return null;
            }          
        }




        // parking
        public bool Parking(string airplaneID, string airportID)
        {
            try
            {
                var entity = db.AirPlanes.SingleOrDefault(x => x.AirplaneId == airplaneID);
                entity.AirPortID = airportID;
                db.SaveChanges();
                return true;
            }
            catch { }
            return false;
        }




        // Remove
        // Edit
        public bool Edit(string airplaneid, int airplanetype, double minrunway)
        {
            try
            {
                var entity = db.AirPlanes.SingleOrDefault(x => x.AirplaneId == airplaneid);
                entity.AirplaneTypeID = airplanetype;
                entity.MinRunWay = minrunway;

                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

		public List<AirPlane> GetALLList()
		{
			try
			{
				var model = (from airplane in db.AirPlanes
							 join airplanetype in db.AirPlaneTypes
							 on airplane.AirplaneTypeID equals airplanetype.AirplaneTypeID
							 where airplane.IsActive==false
							
							 select new AirPlane()
							 {
								 PlaneID = airplane.AirplaneId,
								 Model = airplane.Model,
								 CruiseSpeed = airplane.CruiseSpeed ?? 0,
								 EmptyWeight = airplane.EmptyWeight ?? 0,
								 MaxTakeOffWeight = airplane.MaxTakeOffWeight ?? 0,
								 FlyMethod = airplane.FlyMethod ?? 0,
								 MinRunWay = airplane.MinRunWay,
								 AirPlaneType = airplanetype.AirPlanTypeName
							 }).ToList();
				return model;
			}
			catch
			{
				return null;
			}
		}

		// Get List
		public List<AirPlane> GetList(double runwaysize)
        {
            try
            {
                var model = (from airplane in db.AirPlanes
                             join airplanetype in db.AirPlaneTypes
                             on airplane.AirplaneTypeID equals airplanetype.AirplaneTypeID
                             where airplane.AirPortID == null
                             && airplane.MinRunWay <= runwaysize
                             select new AirPlane()
                             {
                                 PlaneID = airplane.AirplaneId,
                                 Model = airplane.Model,
                                 CruiseSpeed = airplane.CruiseSpeed ?? 0,
                                 EmptyWeight = airplane.EmptyWeight ?? 0,
                                 MaxTakeOffWeight = airplane.MaxTakeOffWeight ?? 0,
                                 FlyMethod = airplane.FlyMethod ?? 0,
                                 MinRunWay = airplane.MinRunWay,
                                 AirPlaneType = airplanetype.AirPlanTypeName
                             }).ToList();
                return model;
            }
            catch
            {
                return null;
            }
        }



        // Info
        public AirPlane Info(string airplaneID)
        {
            try
            {
                var model = (from airplane in db.AirPlanes
                             join airplanetype in db.AirPlaneTypes
                             on airplane.AirplaneTypeID equals airplanetype.AirplaneTypeID
                             join airport in db.AirPorts
                             on airplane.AirPortID equals airport.AirportID
							 where airplane.AirplaneId==airplaneID
                             select new AirPlane()
                             {
                                 PlaneID = airplane.AirplaneId,
                                 Model = airplane.Model,
                                 CruiseSpeed = airplane.CruiseSpeed ?? 0,
                                 EmptyWeight = airplane.EmptyWeight ?? 0,
                                 MaxTakeOffWeight = airplane.MaxTakeOffWeight ?? 0,
                                 FlyMethod = airplane.FlyMethod ?? 0,
                                 MinRunWay = airplane.MinRunWay,
                                 AirPlaneType = airplanetype.AirPlanTypeName,
                                 AirportId = airplane.AirPortID,
                                 AirportName = airport.AirportName
                             }).First();
                return model;
            }
            catch { }
            return null;
        }



        // get airplane type id
        public int getAirplaneTypeId(string airplanetype)
        {
            int AirplaneTypeId = 0;
            try
            {
                AirplaneTypeId= db.AirPlaneTypes.SingleOrDefault(x => x.AirPlanTypeName == airplanetype).AirplaneTypeID;
            }
            catch { }
            return AirplaneTypeId;
        }



        // get list airplane type
        public List<AirPlaneType> GetListAirPlaneType()
        {
            try
            {
                var model = (from airplanetype in db.AirPlaneTypes
                             select new DTO.AirPlaneType()
                             {
                                 AirplaneTypeId = airplanetype.AirplaneTypeID,
                                 AirplaneTypeName = airplanetype.AirPlanTypeName
                             }).ToList();
                return model;
            }
            catch
            {
                return null;
            }
        }
           
    }
}
