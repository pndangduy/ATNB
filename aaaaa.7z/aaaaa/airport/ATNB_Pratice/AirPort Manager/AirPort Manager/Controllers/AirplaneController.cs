﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BUS;
using DTO;
using AirPort_Manager.Models;

namespace AirPort_Manager.Controllers
{
    public class AirplaneController : Controller
    {
        AirplaneBUS airplaneBUS = null;
        public AirplaneController()
        {
            airplaneBUS = new AirplaneBUS();
        }

		public ActionResult Index()
		{
			var model = airplaneBUS.GetALLList();
			return View(model);
		}

        // Info
        public ActionResult Info(string Id)
        {
            var model = airplaneBUS.Info(Id);
            return View(model);
        }



        // Add airport
        public ActionResult AddAirport(double Id)
        {
            var model = airplaneBUS.GetList(Id);
            return View(model);
        }


        // Edit airplane type and min runway size
        [HttpGet]
        public ActionResult Edit(string Id)
        {
            EditAirplanetypeAndMinrunwayModel model = new EditAirplanetypeAndMinrunwayModel();
            model.AirplaneId = Id;
            SetListAirplaneType();
            return View(model);
        }
        [HttpPost]
        public ActionResult Edit(EditAirplanetypeAndMinrunwayModel model)
        {
            if (ModelState.IsValid)
            {
                if (airplaneBUS.Edit(model.AirplaneId, model.AirplaneTypeId, model.MinRunway))
                {
                    return RedirectToAction("Index", "Airport");
                }
                else
                {
                    ModelState.AddModelError("","Have a problem, please check and try again!");
                }
            }
            SetListAirplaneType();
            return View();
        }




        //set list of airplane type
        public void SetListAirplaneType(int? AirplaneTypeId = null)
        {
            ViewBag.AirplaneTypeId = new SelectList(airplaneBUS.GetListAirPlaneType(), "AirplaneTypeId", "AirplaneTypeName", AirplaneTypeId);
        }
    }
}