namespace DAO.EF
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class AirportDbContext : DbContext
    {
        public AirportDbContext()
            : base("name=AirportDbContext")
        {
        }

        public virtual DbSet<AirPlane> AirPlanes { get; set; }
        public virtual DbSet<AirPlaneType> AirPlaneTypes { get; set; }
        public virtual DbSet<AirPort> AirPorts { get; set; }
        public virtual DbSet<Helicopter> Helicopters { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AirPlane>()
                .Property(e => e.AirplaneId)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<AirPlane>()
                .Property(e => e.Model)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<AirPlane>()
                .Property(e => e.AirPortID)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<AirPort>()
                .Property(e => e.AirportID)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Helicopter>()
                .Property(e => e.HelecopterID)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Helicopter>()
                .Property(e => e.Model)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Helicopter>()
                .Property(e => e.AirPortID)
                .IsFixedLength()
                .IsUnicode(false);
        }
    }
}
