namespace DAO.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("AirPort")]
    public partial class AirPort
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public AirPort()
        {
            AirPlanes = new HashSet<AirPlane>();
            Helicopters = new HashSet<Helicopter>();
        }

        [StringLength(7)]
        public string AirportID { get; set; }

        [Required]
        [StringLength(100)]
        public string AirportName { get; set; }

        public double RunwaySize { get; set; }

        public int MaxAirplaneParkingPlace { get; set; }

        public int MaxHelicopterParkingPlace { get; set; }

        public bool IsActive { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<AirPlane> AirPlanes { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Helicopter> Helicopters { get; set; }
    }
}
