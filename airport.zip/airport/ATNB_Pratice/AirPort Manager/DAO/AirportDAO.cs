﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;

namespace DAO
{
    public class AirportDAO
    {
        EF.AirportDbContext db = null;
        public AirportDAO()
        {
            db = new EF.AirportDbContext();
        }



        // Get list
        public List<Airport> GetList()
        {
            try
            {
                var airports = (from airport in db.AirPorts
                                where airport.IsActive == true
                                select new Airport()
                                {
                                    AirportID = airport.AirportID,
                                    AirportName = airport.AirportName,
                                    RunwaySize = airport.RunwaySize,
                                    MaxAirPlanePakingPlace = airport.MaxAirplaneParkingPlace,
                                    MaxHelicopterPakingPlace = airport.MaxHelicopterParkingPlace,
                                    IsActive = airport.IsActive
                                }).ToList();
                return airports;
            }
            catch
            {
                return null;
            }
        }



        // Add
        public string Add(Airport airport)
        {
            try
            {
                EF.AirPort entity = new EF.AirPort()
                {
                    AirportID = airport.AirportID,
                    AirportName = airport.AirportName,
                    RunwaySize = airport.RunwaySize,
                    MaxAirplaneParkingPlace = airport.MaxAirPlanePakingPlace,
                    MaxHelicopterParkingPlace = airport.MaxHelicopterPakingPlace,
                    IsActive = airport.IsActive,
                };

                db.AirPorts.Add(entity);
                db.SaveChanges();
                return entity.AirportID;
            }
            catch { }
            return null;
        }



        // Info
        public Airport Info(string airportID)
        {
            try
            {
                var model = (from airport in db.AirPorts
                             where airport.AirportID == airportID
                             select new Airport()
                             {
                                 AirportID = airport.AirportID,
                                 AirportName = airport.AirportName,
                                 RunwaySize = airport.RunwaySize,
                                 IsActive=airport.IsActive,
                                 MaxAirPlanePakingPlace = airport.MaxAirplaneParkingPlace,
                                 MaxHelicopterPakingPlace = airport.MaxHelicopterParkingPlace
                             }).First();
                if (!string.IsNullOrEmpty(model.AirportID))
                {
                    model.ListOfAirPlane = (from airplane in db.AirPlanes
                                            where airplane.AirPortID == model.AirportID
                                            select new AirPlane()
                                            {
                                                PlaneID = airplane.AirplaneId,
                                                Model = airplane.Model,
                                                CruiseSpeed = airplane.CruiseSpeed ?? 0,
                                                EmptyWeight = airplane.EmptyWeight ?? 0,
                                                MaxTakeOffWeight = airplane.MaxTakeOffWeight ?? 0,
                                                FlyMethod = airplane.FlyMethod ?? 0,
                                                MinRunWay = airplane.MinRunWay,
                                                AirPlaneTypeID = airplane.AirplaneTypeID ?? 0
                                            }).ToList();

                    model.ListOfHelicopter = (from helicopter in db.Helicopters
                                              where helicopter.AirPortID == model.AirportID
                                              select new DTO.Helicopter()
                                              {
                                                  PlaneID = helicopter.HelecopterID,
                                                  Model = helicopter.Model,
                                                  CruiseSpeed = helicopter.CruiseSpeed ?? 0,
                                                  EmptyWeight = helicopter.EmptyWeight ?? 0,
                                                  MaxTakeOffWeight = helicopter.MaxTakeOffWeight ?? 0,
                                                  FlyMethod = helicopter.FlyMethod ?? 0,
                                                  Range = helicopter.Rang ?? 0
                                              }).ToList();
                }
                return model;
            }
            catch { }
            return null;
        }



        // Check exist
        public bool IsExist(string airportId)
        {
            try
            {
                if (!string.IsNullOrEmpty(db.AirPorts.SingleOrDefault(x => x.AirportID == airportId).AirportID))
                {
                    return true;
                }
            }
            catch { }
            return false;
        }



        // Delete
        public bool Delete(string airportId)
        {
            try
            {
                var entity = db.AirPorts.SingleOrDefault(x => x.AirportID == airportId && x.IsActive == true);
                if (entity.IsActive == true)
                {
                    entity.IsActive = false;
                    db.SaveChanges();
                    return true;
                }
            }
            catch { }
            return false;
        }
    }
}
