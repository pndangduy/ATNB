﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    /// <summary>
    /// 05112018-1418
    /// class: airplane
    /// defind a airplane
    /// </summary>
    public class AirPlane : Plane
    {
        // Min runway: min runway air plane need to take off
        public double MinRunWay { get; set; }
        // Airplane type ID
        public int AirPlaneTypeID { get; set; }
        // Airplane type name
        public string AirPlaneType { get; set; }

        

        // Contrustor
        public AirPlane(string planeid, string model, double cruisespeed, double emptyweight, double maxtakeoffweight, int flymethod, double minrunway, int airplanetype):base (planeid,model,cruisespeed,emptyweight,maxtakeoffweight,flymethod)
        {
            this.MinRunWay = minrunway;
            this.AirPlaneTypeID = airplanetype;
        }



        // Defaule constructor
        public AirPlane()
        {
        }
    }
}
