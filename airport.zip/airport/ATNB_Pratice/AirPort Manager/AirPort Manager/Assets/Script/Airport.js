﻿//function deleteAirport(airportId) {
//    var xhttp;
//    if (airportId.length <= 0) {
//        window.alert("No airport selected!");
//    }
//    else {
//        xhttp = new XMLHttpRequest();
//        xhttp.onreadystatechange = function () {
//            if (this.readyState == 4 && this.status == 200 && this.responseText == "True") {
//                window.location.href = "/Home/Index";
//            }
//        };
//        xhttp.open("GET", "Delete?Id=" + airportId, true);
//        xhttp.send();
//    }   
//}