﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BUS;
using DTO;

namespace AirPort_Manager.Controllers
{
    public class HomeController : Controller
    {
        AirportBUS airportBUS = null;
        public HomeController()
        {
            airportBUS = new AirportBUS();
        }



        public ActionResult Index()
        {
            var model = airportBUS.GetList();
            return View(model);
        }

    }
}