﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BUS;
using DTO;
using AirPort_Manager.Models;


namespace AirPort_Manager.Controllers
{
    public class HelicopterController : Controller
    {
        HelicopterBUS helicopterBUS = null;
        public HelicopterController()
        {
            helicopterBUS = new HelicopterBUS();
        }



        // Info
        public ActionResult Info(string Id)
        {
            var model = helicopterBUS.Info(Id);
            return View(model);
        }


        // Edit
        [HttpGet]
        public ActionResult Edit(string Id)
        {
            var helicopter = helicopterBUS.Info(Id);
            if(helicopter!=null)
            {
                var model = new EditHelicopterModel()
                {
                    HelicopterId = helicopter.PlaneID,
                    CruiseSpeed = helicopter.CruiseSpeed,
                    MaxTakeOffWeight = helicopter.MaxTakeOffWeight
                };
                return View(model);
            }
            else
            {
                ModelState.AddModelError("", "Helicopter is not exist!");
            }
            return View();
        }
        [HttpPost]
        public ActionResult Edit(EditHelicopterModel model)
        {
            if(ModelState.IsValid)
            {
                if(helicopterBUS.Edit(model.HelicopterId,model.CruiseSpeed,model.MaxTakeOffWeight))
                {
                    return RedirectToAction("Index", "Helicopter");
                }
                else
                {
                    ModelState.AddModelError("", "Have a problem when save, please check and try again");
                }
            }
            return View();
        }



        // List
        public ActionResult List()
        {
            var model = helicopterBUS.GetList();
            return View(model);
        }
    }
}