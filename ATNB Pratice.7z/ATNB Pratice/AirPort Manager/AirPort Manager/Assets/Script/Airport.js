﻿//Add airplane into airport
function addNewAirplane(airplaneid, airportid) {
    if (airplaneid.length > 0) {
        xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200 && this.responseText == "True") {
                window.alert("Success!");
                var tr = "#" + airplaneid;
                $(tr).remove();
            }
        };
        var link = "/Airport/AddNewAirplane?airplaneid=" + airplaneid + "&airportid=" + airportid;
        xhttp.open("POT", link, true);
        xhttp.send();
    }
}
function addNewHelicopter(helicopterid, airportid) {
    if (helicopterid.length > 0) {
        xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200 && this.responseText == "True") {
                window.alert("Success!");
                var tr = "#" + helicopterid;
                $(tr).remove();
            }
        };
        var link = "/Airport/AddNewHelicopter?helicopterid=" + helicopterid + "&airportid=" + airportid;
        xhttp.open("POT", link, true);
        xhttp.send();
    }
}


// Remove airplane from airport
function removeAirplane(airplaneid) {
    if (airplaneid.length > 0) {
        xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200 && this.responseText == "True") {
                window.alert("Success!");

                var tr = "#" + airplaneid;
                $(tr).remove();
            }
        };
        var link = "/Airport/RemoveAirplane?airplaneid=" + airplaneid;
        xhttp.open("POT", link, true);
        xhttp.send();
    }
}
// Remove airplane from airport
function removeHelicopter(helicopterid) {
    if (helicopterid.length > 0) {
        xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200 && this.responseText == "True") {
                window.alert("Success!");

                var tr = "#" + helicopterid;
                $(tr).remove();
            }
        };
        var link = "/Airport/RemoveHelicopter?helicopterid=" + helicopterid;
        xhttp.open("POT", link, true);
        xhttp.send();
    }
}
