﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace AirPort_Manager.Models
{
    public class EditHelicopterModel
    {
        [Key]
        [Required]
        public string HelicopterId { get; set; }

        [Required]
        public double CruiseSpeed { get; set; }

        [Required]
        public double MaxTakeOffWeight { get; set; }
    }
}