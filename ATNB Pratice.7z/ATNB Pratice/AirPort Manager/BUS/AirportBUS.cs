﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAO;
using DTO;

namespace BUS
{
    public class AirportBUS
    {
        AirportDAO airportDAO;
        AirPlaneDAO airplaneDAO;
        HelicopterDAO helicopterDAO;
        public AirportBUS()
        {
            airportDAO = new AirportDAO();
            airplaneDAO = new AirPlaneDAO();
            helicopterDAO = new HelicopterDAO();
        }



        // Import data
        public void ImportData(List<string> data)
        {
            if (data != null)
            {
                if (data.Count() > 0)
                {
                    foreach (var item in data)
                    {
                        var row = item.Split(',').ToList();
                        if (row.Count() > 0)
                        {
                            if (!string.IsNullOrEmpty(row[0]) && (row[0].Trim().Substring(0, 2) == "AP" || row[0].Trim().Substring(0, 2) == "ap") && !string.IsNullOrEmpty(row[1]))
                            {
                                string airportid = row[0].Trim();
                                string airportname = row[1].Trim();
                                double runwaysize = double.Parse(row[2]);
                                int maxairplanetakeparkplace = int.Parse(row[3]);
                                string lstofairplane = row[4].Trim();
                                List<string> listofairplane = lstofairplane.Split(' ').ToList();
                                int maxhelicoptertakeparkplace = int.Parse(row[5]);
                                string lstofhelicopter = row[6].Trim();
                                List<string> listofhelicopter = lstofhelicopter.Split(' ').ToList();

                                Airport airport = new Airport(airportid, airportname, runwaysize, maxairplanetakeparkplace, listofairplane, maxhelicoptertakeparkplace, listofhelicopter, true);
                                Add(airport);

                                if (listofairplane.Count() > 0)
                                {
                                    foreach (var airplaneID in listofairplane)
                                    {
                                        airplaneDAO.Parking(airplaneID, airportid);
                                    }
                                }

                                if (listofhelicopter.Count() > 0)
                                {
                                    foreach (var helicopterID in listofhelicopter)
                                    {
                                        helicopterDAO.Parking(helicopterID, airportid);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }



        // Export data
        public string ExportData(string path, string airportid)
        {
            try
            {
                var Airport = airportDAO.Info(airportid);
                if (Airport != null)
                {
                    if (Airport.ListOfAirPlane.Count() >= 1 && Airport.ListOfHelicopter.Count >= 1)
                    {
                        List<string> data = new List<string>()
                        {
                            "Airport Information",
                            "Airport ID,name,runway size,max airplane paking place,max helicopter paking place",
                            string.Format("{0},{1},{2},{3},{4}",Airport.AirportID,Airport.AirportName,Airport.RunwaySize,Airport.MaxAirPlanePakingPlace,Airport.MaxHelicopterPakingPlace),
                    };
                        data.Add("");
                        data.Add("Airplane Information");
                        data.Add("Airplane ID,model,cruise speed,empty weight,max takeoff weight,fly method,min needed runway size, airplane type");
                        foreach (var airplane in Airport.ListOfAirPlane)
                        {
                            data.Add(string.Format("{0},{1},{2},{3},{4},{5},{6},{7}", airplane.PlaneID, airplane.Model, airplane.CruiseSpeed, airplane.EmptyWeight, airplane.MaxTakeOffWeight, airplane.FlyMethod, airplane.MinRunWay, airplane.AirPlaneType));

                        }
                        data.Add("");
                        data.Add("Helicopter Information");
                        data.Add("Helicopter ID,model,cruise speed,empty weight,max takeoff weight,range,fly method");
                        foreach (var helicopter in Airport.ListOfHelicopter)
                        {  
                            data.Add(string.Format("{0},{1},{2},{3},{4},{5},{6}", helicopter.PlaneID, helicopter.Model, helicopter.CruiseSpeed, helicopter.EmptyWeight, helicopter.MaxTakeOffWeight,helicopter.Range, helicopter.FlyMethod));
                        }
                        string filename= Airport.AirportName + "-" + COMMON.cmDateTime.toString() + ".csv";
                        path += filename;
                        if (COMMON.CSVFile.Write(data, path))
                        {
                            return filename;
                        }
                    }
                }
                return null;
            }
            catch
            {
                return null;
            }
        }



        // Add
        public string Add(Airport airport)
        {
            return airportDAO.Add(airport);
        }



        // Get list
        public List<DTO.Airport> GetList()
        {
            return airportDAO.GetList();
        }



        // Info
        public DTO.Airport Info(string airportID)
        {
            return airportDAO.Info(airportID);
        }



        // Check exist
        public bool IsExist(string airportId)
        {
            return airportDAO.IsExist(airportId);
        }



        // Delete
        public bool Delete(string airportId)
        {
            return airportDAO.Delete(airportId);
        }



        // Get runway size
        public double GetRunwaySize(string airportid)
        {
            return airportDAO.GetRunwaySize(airportid);
        }
    }
}
