﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    /// <summary>
    /// 05112018-1416
    /// class: Helicopter
    /// Defind a helicopter
    /// </summary>
    public class Helicopter: Plane
    {
        // The range helicopter can fly
        public double Range { get; set; }




        // Default constructor
        public Helicopter()
        {

        }



        // constructor
        public Helicopter(string planeid, string model, double cruisespeed, double emptyweight, double maxtakeoffweight, string flymethod, double range): base(planeid, model, cruisespeed, emptyweight, maxtakeoffweight, flymethod)
        {
            this.Range = range;
        }
    }
}
