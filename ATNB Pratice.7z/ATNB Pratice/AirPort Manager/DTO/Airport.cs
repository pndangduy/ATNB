﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    /// <summary>
    /// 05112018
    /// class: Air port
    /// Defind a air port.
    /// </summary>
    public class Airport
    {
        // Airport ID
        public string AirportID { get; set; }
        // Airport name
        public string AirportName { get; set; }
        // size of running way
        public double RunwaySize { get; set; }
        // Maximun parking place for fixed wing plane
        public int MaxAirPlanePakingPlace { get; set; }
        // Maximun parking place for rotated wing plane
        public int MaxHelicopterPakingPlace { get; set; }
        // List of fixed wing plane of airport
        public List<AirPlane> ListOfAirPlane { get; set; }
        public List<string> ListOfAirplaneId { get; set; }
        // List of rotated wing plane of airport
        public List<Helicopter> ListOfHelicopter { get; set; }
        public List<string> ListOfHelicopterId { get; set; }
        public bool IsActive { get; set; }



        // constructor
        public Airport(string id,string name, double runwaysize, int maxairplanepakingplace,List<string> listofairplane, int maxofhelicoptertakingplace, List<string> listofhelicopter,bool isactive)
        {
            this.AirportID = id;
            this.AirportName = name;
            this.RunwaySize = runwaysize;
            this.MaxAirPlanePakingPlace = maxairplanepakingplace;
            this.ListOfAirplaneId = listofairplane;
            this.MaxHelicopterPakingPlace = maxofhelicoptertakingplace;
            this.ListOfHelicopterId = listofhelicopter;
            this.IsActive=isactive;
        }



        // Default constructor
        public Airport()
        {

        }
    }
}
