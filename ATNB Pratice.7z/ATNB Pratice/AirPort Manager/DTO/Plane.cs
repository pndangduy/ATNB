﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    /// <summary>
    /// 02112018-1403
    /// Class: Plane
    /// Description: Defind a farther class for Airplane class and Helicopter class. Content main info of a plane
    /// </summary>
    public class Plane
    {
        // id of plane
        // ID have 7 characters, started by “FW” -fixed wing airplane, “RW” -helicopter and “AP” -airport, followed by 5 digits.
        public string PlaneID { get; set; }
        // model of plane
        public string Model { get; set; }
        // Cruise speed of plane: tốc độ hành trình
        public double CruiseSpeed { get; set; }
        // Empty weight: weight of plane when plane empty
        public double EmptyWeight { get; set; }
        // Max take off weight: max weight the plane can take off
        public double MaxTakeOffWeight { get; set; }
        // Fly method: "fixed wing" or “rotated wing"
        public string FlyMethod { get; set; }
        // Airport name
        public string AirportName { get; set; }
        public string AirportId { get; set; }



        // Default constructor
        public Plane()
        {

        }



        // Contructor
        public Plane(string planeid,string model, double cruisespeed, double emptyweight, double maxtakeoffweight, string flymethod)
        {
            this.PlaneID = planeid;
            this.Model = model;
            this.CruiseSpeed = cruisespeed;
            this.EmptyWeight = emptyweight;
            this.MaxTakeOffWeight = maxtakeoffweight;
            this.FlyMethod = flymethod;
        }
    }
}
