namespace DAO.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("AirPlane")]
    public partial class AirPlane
    {
        [StringLength(7)]
        public string AirplaneId { get; set; }

        [Required]
        [StringLength(40)]
        public string Model { get; set; }

        public double? CruiseSpeed { get; set; }

        public double? EmptyWeight { get; set; }

        public double? MaxTakeOffWeight { get; set; }

        [StringLength(50)]
        public string FlyMethod { get; set; }

        public int? AirplaneTypeID { get; set; }

        public double MinRunWay { get; set; }

        [StringLength(7)]
        public string AirPortID { get; set; }

        public bool IsActive { get; set; }

        public virtual AirPlaneType AirPlaneType { get; set; }

        public virtual AirPort AirPort { get; set; }
    }
}
