﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;


namespace DAO
{
    public class HelicopterDAO
    {
        EF.AirportDbContext db;
        public HelicopterDAO()
        {
            db = new EF.AirportDbContext();
        }
        private const float times = (float)1.5;



        // Add
        public string Add(Helicopter helicopter)
        {
            try
            {
                EF.Helicopter entity = new EF.Helicopter();

                entity.HelecopterID = helicopter.PlaneID;
                entity.Model = helicopter.Model;
                entity.CruiseSpeed = helicopter.CruiseSpeed;
                entity.EmptyWeight = helicopter.EmptyWeight;
                entity.MaxTakeOffWeight = helicopter.MaxTakeOffWeight;
                entity.Rang = helicopter.Range;
                entity.FlyMethod = helicopter.FlyMethod;
                entity.AirPortID = null;

                db.Helicopters.Add(entity);
                db.SaveChanges();

                return entity.HelecopterID;
            }
            catch
            {
                return null;
            }
        }



        // parking
        public bool Parking(string helicopterID,string airportID)
        {
            try
            {
                var entity = db.Helicopters.SingleOrDefault(x => x.HelecopterID == helicopterID);
                entity.AirPortID = airportID;
                db.SaveChanges();
                return true;
            }
            catch { }
            return false;
        }
        // Remove from airplane
        public bool RemoveFromAirport(string helicopterid)
        {
            try
            {
                var efHelicopter = db.Helicopters.SingleOrDefault(x => x.HelecopterID == helicopterid);
                if (efHelicopter != null)
                {
                    efHelicopter.AirPortID = null;
                    db.SaveChanges();
                    return true;
                }

                return false;
            }
            catch
            {
                return false;
            }
        }



        // Remove
        // Edit
        public bool Edit(string helicopterid, double cruisespeed, double maxtakeoffweight)
        {
            try
            {
                var entity = db.Helicopters.SingleOrDefault(x => x.HelecopterID == helicopterid);
                if(entity!=null)
                {
                    if(maxtakeoffweight <= (entity.EmptyWeight * times))
                    {
                        entity.CruiseSpeed = cruisespeed;
                        entity.MaxTakeOffWeight = maxtakeoffweight;

                        db.SaveChanges();
                        return true;
                    }                  
                }

            }
            catch { }
            return false;
        }



        // Info
        public Helicopter Info(string helicopterID)
        {
            try
            {
                var model = (from helicopter in db.Helicopters
                             join airport in db.AirPorts
                             on helicopter.AirPortID equals airport.AirportID
                             where helicopter.HelecopterID==helicopterID
                             select new Helicopter()
                             {
                                 PlaneID = helicopter.HelecopterID,
                                 Model = helicopter.Model,
                                 CruiseSpeed = helicopter.CruiseSpeed ?? 0,
                                 EmptyWeight = helicopter.EmptyWeight ?? 0,
                                 MaxTakeOffWeight = helicopter.MaxTakeOffWeight ?? 0,
                                 FlyMethod = helicopter.FlyMethod,
                                 Range = helicopter.Rang??0,
                                 AirportId = helicopter.AirPortID,
                                 AirportName = airport.AirportName
                             }).First();
                return model;
            }
            catch { }
            return null;
        }



        // Get list
        public List<Helicopter> GetList(double runwaysize)
        {
            try
            {
                var model = (from helicopter in db.Helicopters
                             where helicopter.AirPortID == null
                             select new Helicopter()
                             {
                                 PlaneID = helicopter.HelecopterID,
                                 Model = helicopter.Model,
                                 CruiseSpeed = helicopter.CruiseSpeed ?? 0,
                                 EmptyWeight = helicopter.EmptyWeight ?? 0,
                                 MaxTakeOffWeight = helicopter.MaxTakeOffWeight ?? 0,
                                 FlyMethod = helicopter.FlyMethod,
                                 Range = helicopter.Rang ??0
                             }).ToList();
                return model;
            }
            catch
            {
                return null;
            }
        }
        public List<Helicopter> GetList()
        {
            try
            {
                var model = (from helicopter in db.Helicopters
                             select new Helicopter()
                             {
                                 PlaneID = helicopter.HelecopterID,
                                 Model = helicopter.Model,
                                 CruiseSpeed = helicopter.CruiseSpeed ?? 0,
                                 EmptyWeight = helicopter.EmptyWeight ?? 0,
                                 MaxTakeOffWeight = helicopter.MaxTakeOffWeight ?? 0,
                                 FlyMethod = helicopter.FlyMethod,
                                 Range = helicopter.Rang ?? 0
                             }).ToList();
                return model;
            }
            catch
            {
                return null;
            }
        }


    }
}
