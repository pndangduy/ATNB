﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMMON
{
    public static class cmDateTime
    {
        public static string toString()
        {
            string str = DateTime.Now.ToString();
            var check = new string[] {" ", "a", "A", "p", "P", "m", "M", "s", "S", "c", "C", "h", "H", ":", "/" };

            foreach (var c in check)
            {
                str = str.Replace(c,string.Empty);
            }

            return str;
        }
    }
}
