﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Web;


/// <summary>
/// CSV File
/// 10112018
/// Class to read and write data with CSV file
/// </summary>

namespace COMMON
{
    public static class CSVFile
    {
        /// <summary>
        /// Read
        /// Read a csv file and return list strong all rows of csv file
        /// </summary>
        /// <param name="stream">stram file</param>
        /// <returns>List<string> Result</returns>
        public static List<string> Read(Stream stream)
        {
            List<string> Result = new List<string>();
            try
            {
                using(StreamReader reader = new StreamReader(stream))
                {
                    string row = reader.ReadLine();
                    while(!string.IsNullOrEmpty(row))
                    {
                        Result.Add(row);
                        row = reader.ReadLine();
                    }
                }
            }
            catch {}
            return Result;
        }


        /// <summary>
        /// Write
        /// </summary>
        /// <param name="data"></param>
        /// <param name="path"></param>
        /// <returns></returns>
        public static bool Write(IEnumerable<string> data,string path)
        {
            try
            {
                StreamWriter writer = new StreamWriter(path, true, Encoding.ASCII);
                foreach(var line in data)
                {
                    writer.WriteLine(line);
                }
                writer.Close();

                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
