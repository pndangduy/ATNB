﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMMON
{
    public static class common
    {
        public static string linkSaveFile = "~/Assets/Files/";
        public static string linkDownloadFile = "/Assets/Files/";
    }
}
