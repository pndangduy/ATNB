﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
	/// <summary>
	/// instance class Helicopter inheritance class Plane
	/// include properties class Plane and property Range
	/// </summary>
	public class Helicopters:Plane
	{
		public string Helicopter_ID { get; set; }
										   //Range
		public decimal Range { get; set; }
		//airport
		public Airport Airport { get; set; }
		public string  Airport_ID { get; set; }
	}
}
