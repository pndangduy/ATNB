﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
	/// <summary>
	/// class fixed wings type
	/// </summary>
	public class FWType
	{
		//fixed wing id
		public string FW_ID { get; set; }
		// type id
		public string FWTypeID { get; set; }
		//name
		public string FWTypeName { get; set; }
	}
}
