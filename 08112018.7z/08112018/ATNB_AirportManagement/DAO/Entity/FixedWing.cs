namespace DAO.Entity
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class FixedWing
    {
        [Key]
        [StringLength(7)]
        public string FW_ID { get; set; }

        [StringLength(40)]
        public string Model { get; set; }

        [StringLength(3)]
        public string FWType_ID { get; set; }

        public decimal? CruiseSpeed { get; set; }

        public decimal? EmptyWeight { get; set; }

        public decimal? MaxTakeOffWeight { get; set; }

        public decimal? MinRunAwaySize { get; set; }

        [StringLength(50)]
        public string FlyMethod { get; set; }

        [Required]
        [StringLength(7)]
        public string Airport_ID { get; set; }

        public virtual Airport Airport { get; set; }

        public virtual FW_Type FW_Type { get; set; }
    }
}
