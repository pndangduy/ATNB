namespace DAO.Entity
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Helicopter")]
    public partial class Helicopter
    {
        [Key]
        [StringLength(7)]
        public string Helicopter_ID { get; set; }

        [StringLength(40)]
        public string Model { get; set; }

        public decimal? CruiseSpeed { get; set; }

        public decimal? EmtyWeight { get; set; }

        public decimal? MaxTakeOffWeight { get; set; }

        public decimal? Range { get; set; }

        [StringLength(50)]
        public string FlyMethod { get; set; }

        [Required]
        [StringLength(7)]
        public string Airport_ID { get; set; }

        public virtual Airport Airport { get; set; }
    }
}
