﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAO;
using DAO.Entity;
using DTO;

namespace DAO
{
	public class AirportDAO
	{
		Entity.AiportManagerDBContext db = null;
		public AirportDAO()
		{
			db = new AiportManagerDBContext();
		}
		
		public List<Entity.Airport> GetAllList()
		{
			var list = (from airport in db.Airports
						orderby airport.Airport_ID
						select new Entity.Airport()
						{
							Airport_ID = airport.Airport_ID,
							Name = airport.Name,
							MaxFWParkingPlace = airport.MaxFWParkingPlace ?? 0,
							MaxHelicopterParkingPlace = airport.MaxHelicopterParkingPlace ?? 0,
							RunawaySize = airport.RunawaySize,
							FixedWings=airport.FixedWings,
							Helicopters=airport.Helicopters				
						}).ToList();
			return list;
		}
		public List<DTO.ListPlane> Detail()
		{
			var list = (from airport in db.Airports
						join fixedwing in db.FixedWings
						on airport.Airport_ID equals fixedwing.Airport_ID
						join helicopter in db.Helicopters
						on airport.Airport_ID equals helicopter.Airport_ID
						select new DTO.ListPlane()
						{
							Airport_Id = airport.Airport_ID,
							FixwedwingId = fixedwing.FW_ID,
							HelicopterId = helicopter.Helicopter_ID
						}).ToList();
			return list;
		}
		public List<Entity.Airport>GetById(string id)
		{
			var list = (from airport in db.Airports
						where airport.Airport_ID==id
						select new Entity.Airport()
						{
							Airport_ID = airport.Airport_ID,
							Name = airport.Name,
							MaxFWParkingPlace = airport.MaxFWParkingPlace ?? 0,
							MaxHelicopterParkingPlace = airport.MaxHelicopterParkingPlace ?? 0,
							RunawaySize=airport.RunawaySize,
							FixedWings=airport.FixedWings,
							Helicopters=airport.Helicopters
						}).ToList();
			return list;
		}
		public bool Create(Entity.Airport airport)
		{
			if (airport==null)
			{
				throw new NullReferenceException();
			}
			else
			{
				Entity.Airport airpo = new Entity.Airport();
				try
				{
					airpo.Airport_ID = airport.Airport_ID;
					airpo.Name = airport.Name;
					airpo.MaxFWParkingPlace = airport.MaxFWParkingPlace;
					airpo.MaxHelicopterParkingPlace = airport.MaxHelicopterParkingPlace;
					airpo.RunawaySize = airport.RunawaySize;
					airpo.FixedWings = airport.FixedWings;
					airpo.Helicopters = airport.Helicopters;
					db.Airports.Add(airpo);
					db.SaveChanges();
					return true;
				}
				catch { }
			}
			return false;
		}
		public bool Delete(string Id)
		{
			if (Id == null)
			{
				throw new NullReferenceException();
			}
			else
			{
				try
				{
					var airport = db.Airports.SingleOrDefault(x => x.Airport_ID == Id);
					db.Airports.Remove(airport);
					db.SaveChanges();
					return true;
				}
				catch { }
			}
			return false;
			
		}
		public bool Edit(Entity.Airport airport)
		{
			if(airport != null)
			{
				try
				{
					var tem = db.Airports.SingleOrDefault(x => x.Airport_ID == airport.Airport_ID);
					if(tem.Airport_ID!=null)
					{
						if(!string.IsNullOrEmpty(airport.Name))
						{
							tem.Name = airport.Name;
						}
						if(airport.MaxFWParkingPlace>0)
						{
							tem.MaxFWParkingPlace = airport.MaxFWParkingPlace;
						}
						if(airport.MaxHelicopterParkingPlace>0)
						{
							tem.MaxHelicopterParkingPlace = airport.MaxHelicopterParkingPlace;
						}
						if(airport.RunawaySize>0)
						{
							tem.RunawaySize = airport.RunawaySize;
						}
						if(airport.FixedWings.Count>0)
						{
							foreach (var item in airport.FixedWings)
							{
								tem.FixedWings.Add(item);
							}
						}
						if(airport.Helicopters.Count>0)
						{
							foreach(var item in airport.Helicopters)
							{
								tem.Helicopters.Add(item);
							}
						}
						db.SaveChanges();
						return true;
					}
				}
				catch { }
			}
			return false;
		}
		
		
	}
}
