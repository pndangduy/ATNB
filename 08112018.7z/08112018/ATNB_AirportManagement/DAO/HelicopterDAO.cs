﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;

namespace DAO
{
	public class HelicopterDAO
	{
		Entity.AiportManagerDBContext db = null;
		public HelicopterDAO()
		{
			db = new Entity.AiportManagerDBContext();
		}

		public string Add(DTO.Helicopters entity)
		{
			if (entity == null)
			{
				throw new NullReferenceException();

			}
			else
			{
				Entity.Helicopter plane = new Entity.Helicopter();
				try
				{
					plane.Helicopter_ID = entity.Helicopter_ID;
					plane.Model = entity.Model;
					plane.CruiseSpeed = entity.CruiseSpeed;
					plane.EmtyWeight = entity.EmtyWeight;
					plane.MaxTakeOffWeight = entity.MaxTakeOffWeight;
					plane.Range = entity.Range;

					plane.FlyMethod = entity.FlyMethod;
					plane.Airport_ID = entity.Airport_ID;

					db.Helicopters.Add(plane);
					db.SaveChanges();
					return plane.Helicopter_ID;
				}
				catch
				{ }
			}
			return null;
		}

		public bool Delete(string Id)
		{
			if (Id == null)
			{
				throw new NullReferenceException();
			}
			else
			{
				try
				{
					var plane = db.Helicopters.SingleOrDefault(x => x.Helicopter_ID == Id);
					db.Helicopters.Remove(plane);
					db.SaveChanges();
					return true;

				}
				catch { }
			}
			return false;
		}



		public bool Edit(DTO.Helicopters helicopter)
		{
			if (helicopter != null)
			{
				try
				{
					var plane = db.Helicopters.SingleOrDefault(x => x.Helicopter_ID == helicopter.Helicopter_ID);
					if (plane.Helicopter_ID != null)
					{
						if (!string.IsNullOrEmpty(helicopter.Model))
						{
							plane.Model = helicopter.Model;
						}

						if (helicopter.CruiseSpeed > 0)
						{
							plane.CruiseSpeed = helicopter.CruiseSpeed;
						}
						if (helicopter.EmtyWeight > 0)
						{
							plane.EmtyWeight = helicopter.EmtyWeight;
						}
						if (helicopter.MaxTakeOffWeight > 0)
						{
							plane.MaxTakeOffWeight = helicopter.MaxTakeOffWeight;
						}
						if (helicopter.Range > 0)
						{
							plane.Range = helicopter.Range;
						}
						if (!string.IsNullOrEmpty(helicopter.FlyMethod))
						{
							plane.FlyMethod = helicopter.FlyMethod;
						}
						if (!string.IsNullOrEmpty(helicopter.Airport_ID))
						{
							plane.Airport_ID = helicopter.Airport_ID;
						}
						db.SaveChanges();
						return true;
					}
				}
				catch { }
			}
			return false;
		}

		public List<DTO.Helicopters> GetAllList()
		{
			var model = (from helicopter in db.Helicopters
						 select new DTO.Helicopters()
						 {
							 Helicopter_ID = helicopter.Helicopter_ID,
							 Model = helicopter.Model,
							 CruiseSpeed = helicopter.CruiseSpeed ?? 0,
							 EmtyWeight = helicopter.EmtyWeight ?? 0,
							 MaxTakeOffWeight = helicopter.MaxTakeOffWeight ?? 0,
							 Range = helicopter.Range ?? 0,
							 FlyMethod = helicopter.FlyMethod,
							 Airport_ID = helicopter.Airport_ID

						 }).ToList();
			return model;
		}

		public List<DTO.Helicopters> GetByID(string ID)
		{
			var model = (from helicopter in db.Helicopters
						 where helicopter.Helicopter_ID==ID
						 select new DTO.Helicopters()
						 {
							 Helicopter_ID = helicopter.Helicopter_ID,
							 Model = helicopter.Model,
							 CruiseSpeed = helicopter.CruiseSpeed ?? 0,
							 EmtyWeight = helicopter.EmtyWeight ?? 0,
							 MaxTakeOffWeight = helicopter.MaxTakeOffWeight ?? 0,
							 Range = helicopter.Range ?? 0,
							 FlyMethod = helicopter.FlyMethod,
							 Airport_ID = helicopter.Airport_ID

						 }).ToList();
			return model;
		}
		
	}

}
	

