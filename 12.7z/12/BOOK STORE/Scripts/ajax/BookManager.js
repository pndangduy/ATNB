﻿function deleteBook(bookid) {
    if (bookid == 0) {
        window.alert("Book is not exist!");
    }
    else {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200 && this.responseText == "True") {
                var tr = "#tr" + bookid;
                $(tr).css("display","none");
                window.alert("Delete book success!");
            }
        };
        xhttp.open("DELETE", "Delete?Id=" + bookid, true);
        xhttp.send();
    }
}


function activeBook(bookid) {
    if (bookid == 0) {
        window.alert("Book Id is null");
    }
    else {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200 && this.responseText == "True") {
                var tr = "#tr" + bookid;
                $(tr).css("display", "block");
                window.alert("Active book success!");
            }
        };
        xhttp.open("GET", "Active?Id=" + bookid, true);
        xhttp.send();
    }
}