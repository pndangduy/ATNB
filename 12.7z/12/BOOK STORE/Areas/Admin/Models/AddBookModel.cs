﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace BOOK_STORE.Areas.Admin.Models
{
    public class AddBookModel
    {
        [Display(Name ="Tiêu đề sách")]
	    public string Title { get; set; }


        [Display(Name = "Danh mục")]
        public int CateId { get; set; }


        [Display(Name = "Tác giả")]
        public int AuthorId { get; set; }


        [Display(Name = "Nhà xuất bản")]
        public int PubId { get; set; }


        [Display(Name = "Giới thiệu")]
        [DataType(DataType.MultilineText)]
        public string Summary { get; set; }


        [Display(Name ="Select picture")]
        [Required(ErrorMessage ="Please select image for this book")]
        public HttpPostedFileBase ImageUrl { get; set; }


        [Display(Name = "Giá")]
        public double Price { get; set; }


        [Display(Name = "Số lượng")]
        public int Quantity { get; set; }


        [DataType(DataType.DateTime)]
        [Required]
        public DateTime CreatedDate { get; set; }


        public DateTime ModifiedDate { get; set; }

        [Required]
        public bool IsActive { get; set; }
    }
}