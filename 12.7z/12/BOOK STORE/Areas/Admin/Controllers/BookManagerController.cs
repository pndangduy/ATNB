﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BOOK_STORE.Areas.Admin.Models;
using System.IO;
using BUS;
using DTO;


namespace BOOK_STORE.Areas.Admin.Controllers
{
    public class BookManagerController : SecurityController
    {
        BookBUS bookBUS = null;
        CategoryBUS categoryBUS = null;
        AuthorBUS authorBUS = null;
        PublisherBUS publisherBUS = null;
        public BookManagerController()
        {
            bookBUS = new BookBUS();
            categoryBUS = new CategoryBUS();
            authorBUS = new AuthorBUS();
            publisherBUS = new PublisherBUS();
        }




        // Index
        public ActionResult Index()
        {
            return View(bookBUS.GetList());
        }




        // ADD
        [HttpGet]
        public ActionResult Add()
        {
            setPublisherList();
            setCategoryList();
            setAuthorList();
            return View();
        }
        [HttpPost]
        public ActionResult Add(AddBookModel model)
        {
            if (ModelState.IsValid)
            {
                Book book = new Book();

                book.Title = model.Title.Trim();
                book.ImageUrl = SavaBookImage(model.ImageUrl, model.Title);
                book.CateId = model.CateId;
                book.AuthorId = model.AuthorId;
                book.PubId = model.PubId;
                book.Summary = model.Summary;
                book.Price = model.Price;
                book.Quantity = model.Quantity;
                book.CreatedDate = DateTime.Now;
                book.IsActive = true;

                if (bookBUS.Add(book))
                {
                    return RedirectToAction("Index", "BookManager", new { area = "admin" });
                }
                ModelState.AddModelError("", "Data is invalid, please check and try again!");
            }

            setPublisherList();
            setCategoryList();
            setAuthorList();
            return View(model);
        }



        // Save book image
        private string SavaBookImage(HttpPostedFileBase image, string bookname)
        {
            try
            {
                // create image name
                string ImageName = bookname + COMMON.clsDateTime.toString() + ".jpg";
                // save image path
                string ImagePath = System.IO.Path.Combine(Server.MapPath("/Data/Image/"), ImageName);
                // save image to Data folder
                image.SaveAs(ImagePath);
                return ImageName;
            }
            catch { }
            return null;
        }



        public void setCategoryList(int? selectedID = null)
        {
            ViewBag.CateID = new SelectList(categoryBUS.GetList(), "CateId", "CateName", selectedID);
        }

        public void setAuthorList(int? selectedID = null)
        {
            ViewBag.AuthorID = new SelectList(authorBUS.GetList(), "AuthorId", "AuthorName", selectedID);
        }

        public void setPublisherList(int? selectedID = null)
        {
            ViewBag.PubId = new SelectList(publisherBUS.GetList(), "PubId", "PubName", selectedID);
        }



        // Delete
        public bool Delete(int Id)
        {
            return bookBUS.Delete(Id);
        }


        // Active
        public bool Active(int Id)
        {
            return bookBUS.Active(Id);
        }
    }
}