﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BUS;
using DTO;


namespace BOOK_STORE.Areas.Admin.Controllers
{
    public class PublisherManagerController : Controller
    {
        PublisherBUS publisherBUS = null;
        public PublisherManagerController()
        {
            publisherBUS = new PublisherBUS();
        }



        // Index
        public ActionResult Index()
        {
            return View(publisherBUS.GetList());
        }
    }
}