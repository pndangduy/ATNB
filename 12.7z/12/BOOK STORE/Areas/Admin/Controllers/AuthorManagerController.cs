﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BOOK_STORE.Areas.Admin.Models;
using BUS;
using DTO;


namespace BOOK_STORE.Areas.Admin.Controllers
{
    public class AuthorManagerController : SecurityController
    {
        AuthorBUS authorBUS = null;
        public AuthorManagerController()
        {
            authorBUS = new AuthorBUS();
        }



        // Index
        public ActionResult Index()
        {
            return View(authorBUS.GetList());
        }



        // Add
        [HttpGet]
        public ActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Add(AddAuthorModel model)
        {
            if(ModelState.IsValid)
            {
                Author entity = new Author();
                entity.AuthorName = model.AuthorName;
                entity.History = model.History;

                if(authorBUS.Add(entity)>0)
                {
                    return RedirectToAction("Index", "AuthorManager", new { area = "Admin" });
                }
                else
                {
                    ModelState.AddModelError("", "Have a problem when try to add a new author");
                }
            }
            return View();
        }
    }
}