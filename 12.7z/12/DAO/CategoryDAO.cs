﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAO;
using DTO;

namespace DAO
{
    public class CategoryDAO
    {
        EF.BookStoreDbContext db = null;
        public CategoryDAO()
        {
            db = new EF.BookStoreDbContext();
        }



        // Get list
        public List<Category> GetList()
        {
            var model = (from category in db.Categories
                         select new Category()
                         {
                             CateId = category.CateId,
                             CateName = category.CateName,
                             Description = category.Description
                         }).ToList();
            return model;
        }



        // Add
        public int Add(Category category)
        {
            if(category!=null)
            {
                EF.Category entity = new EF.Category();
                try
                {
                    entity.CateName = category.CateName;
                    entity.Description = category.Description;
                    db.Categories.Add(entity);
                    db.SaveChanges();
                    return entity.CateId;
                }
                catch { }
            }
            return 0;
        }



        // Remove
        public bool Remove(int categoryId)
        {
            if(categoryId>0)
            {
                try
                {
                    var entity = db.Categories.SingleOrDefault(x => x.CateId == categoryId);
                    db.Categories.Remove(entity);
                    db.SaveChanges();
                    return true;
                }
                catch { }
            }
            return false;
        }



        //Edit
        public bool Edit(Category category)
        {
            if(category!=null)
            {
                try
                {
                    var entity = db.Categories.SingleOrDefault(x => x.CateId == category.CateId);
                    if(entity.CateId>0)
                    {
                        if(!string.IsNullOrEmpty(category.CateName))
                        {
                            entity.CateName = category.CateName;
                        }
                        if(!string.IsNullOrEmpty(category.Description))
                        {
                            entity.Description = category.Description;
                        }
                        db.SaveChanges();
                        return true;
                    }
                }
                catch
                {

                }
            }
            return false;
        }
    }
}
