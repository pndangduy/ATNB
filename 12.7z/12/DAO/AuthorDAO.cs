﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAO;
using DTO;

namespace DAO
{
    public class AuthorDAO
    {
        EF.BookStoreDbContext db = null;
        public AuthorDAO()
        {
            db = new EF.BookStoreDbContext();
        }



        // Get list
        public List<Author> GetList()
        {
            var model = (from author in db.Authors
                         select new Author()
                         {
                             AuthorId = author.AuthorId,
                             AuthorName = author.AuthorName,
                             History = author.History
                         }).ToList();
            return model;
        }



        // Add
        public int Add(Author author)
        {
            if(author!=null)
            {
                EF.Author entity = new EF.Author();
                try
                {
                    entity.AuthorName = author.AuthorName;
                    entity.History = author.History;
                    db.Authors.Add(entity);
                    db.SaveChanges();
                    return entity.AuthorId;
                }
                catch { }
            }
            return 0;
        }



        // Remove
        public bool Remove(int authorId)
        {
            if(authorId>0)
            {
                try
                {
                    var entity = db.Authors.SingleOrDefault(x => x.AuthorId == authorId);
                    db.Authors.Remove(entity);
                    db.SaveChanges();
                    return true;
                }
                catch { }
            }
            return false;
        }



        // Edit
        public bool Edit(Author author)
        {
            if(author!=null)
            {
                try
                {
                    var entity = db.Authors.SingleOrDefault(x => x.AuthorId == author.AuthorId);
                    if(entity.AuthorId>0)
                    {
                        if(!string.IsNullOrEmpty(author.AuthorName))
                        {
                            entity.AuthorName = author.AuthorName;
                        }
                        if(!string.IsNullOrEmpty(author.History))
                        {
                            entity.History = author.History;
                        }
                        db.SaveChanges();
                    }
                }
                catch { }
            }
            return false;
        }
    }
}
