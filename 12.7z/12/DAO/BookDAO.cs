﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAO;
using DTO;

namespace DAO
{
    public class BookDAO
    {
        EF.BookStoreDbContext db = null;
        public BookDAO()
        {
            db = new EF.BookStoreDbContext();
        }



        // Get list
        public List<DTO.Book> GetList()
        {
            var model = (from book in db.Books
                         join category in db.Categories
                         on book.CateId equals category.CateId
                         join author in db.Authors
                         on book.AuthorId equals author.AuthorId
                         join publisher in db.Publishers
                         on book.PubId equals publisher.PubId
                         where(book.IsActive==true)
                         select new DTO.Book()
                         {
                             BookId = book.BookId,
                             Title = book.Title,
                             CateId = book.CateId,
                             CateName = category.CateName,
                             AuthorId = book.AuthorId,
                             AuthorName = author.AuthorName,
                             PubId = book.PubId,
                             PubName = publisher.PubName,
                             Summary = book.Summary,
                             ImageUrl = book.ImageUrl,
                             Price = book.Price,
                             Quantity = book.Quantity,
                             CreatedDate = book.CreatedDate,
                             ModifiedDate = book.ModifiedDate,
                             IsActive = book.IsActive
                         }).ToList();
            return model;
        }



        // Add new book
        public bool Add(Book book)
        {
            if (book != null)
            {
                try
                {
                    EF.Book entity = new EF.Book();

                    entity.Title = book.Title;
                    entity.CateId = book.CateId;
                    entity.AuthorId = book.AuthorId;
                    entity.PubId = book.PubId;
                    entity.Summary = book.Summary;
                    entity.ImageUrl = book.ImageUrl;
                    entity.Price = book.Price;
                    entity.Quantity = book.Quantity;
                    entity.CreatedDate = book.CreatedDate;
                    entity.IsActive = book.IsActive;

                    db.Books.Add(entity);
                    db.SaveChanges();

                    if(entity.BookId>0)
                    {
                        return true;
                    }
                }
                catch { }
            }
            return false;
        }
        
        
        
        //Info
        public Book Info(int bookid)
        {
            try
            {
                var model = (from book in db.Books
                             join category in db.Categories
                             on book.CateId equals category.CateId
                             join author in db.Authors
                             on book.AuthorId equals author.AuthorId
                             join publisher in db.Publishers
                             on book.PubId equals publisher.PubId
                             where book.BookId == bookid
                             select new DTO.Book()
                             {
                                 BookId = book.BookId,
                                 Title = book.Title,
                                 CateId = book.CateId,
                                 CateName = category.CateName,
                                 AuthorId = book.AuthorId,
                                 AuthorName = author.AuthorName,
                                 PubId = book.PubId,
                                 PubName = publisher.PubName,
                                 Summary = book.Summary,
                                 ImageUrl = book.ImageUrl,
                                 Price = book.Price,
                                 Quantity = book.Quantity,
                                 CreatedDate = book.CreatedDate,
                                 ModifiedDate = book.ModifiedDate,
                                 IsActive = book.IsActive
                             }).First();
                if(model!=null)
                {
                    var comments = (from comment in db.Comments
                                    where comment.BookId == bookid
                                    && comment.IsActive == true
                                    select new Comment()
                                    {
                                        CommentId = comment.CommentId,
                                        BookId = comment.BookId,
                                        Content = comment.Content,
                                        CreatedDate = comment.CreatedDate,
                                        IsActive = comment.IsActive
                                    }
                                  ).ToList();
                    if(comments.Count>0)
                    {
                        model.Comments = comments;
                    }
                    return model;
                }
            }
            catch { }
            return null;
        }



        // Edit
        // Delete
        public bool Delete(int bookid)
        {
            try
            {
                var book = db.Books.SingleOrDefault(x => x.BookId == bookid && x.IsActive == true);
                if(book!=null)
                {
                    book.IsActive = false;
                    db.SaveChanges();
                    if(book.IsActive==false)
                    {
                        return true;
                    }
                }
            }
            catch
            {

            }
            return false;
        }



        // Active
        public bool Active(int bookid)
        {
            try
            {
                var book = db.Books.SingleOrDefault(x => x.BookId == bookid && x.IsActive == false);
                if (book != null)
                {
                    book.IsActive = true;
                    db.SaveChanges();
                    if (book.IsActive == true)
                    {
                        return true;
                    }
                }
            }
            catch
            {

            }
            return false;
        }

    }
}
