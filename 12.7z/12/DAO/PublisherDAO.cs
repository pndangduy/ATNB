﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;

namespace DAO
{
    public class PublisherDAO
    {
        EF.BookStoreDbContext db = null;
        public PublisherDAO()
        {
            db = new EF.BookStoreDbContext();
        }



        // Get list
        public List<Publisher> GetList()
        {
            var model = (from publisher in db.Publishers
                         select new Publisher()
                         {
                             PubId = publisher.PubId,
                             PubName = publisher.PubName,
                             Description = publisher.Description
                         }).ToList();
            return model;
        }



        // Add
        public bool Add(Publisher publisher)
        {
            EF.Publisher entity = new EF.Publisher();
            entity.PubName = publisher.PubName;
            entity.Description = publisher.Description;

            try
            {
                db.Publishers.Add(entity);
                db.SaveChanges();
            }
            catch { }
            if(entity.PubId>0)
            {
                return true;
            }
            return false;
        }



        // Edit
        public bool Edit(Publisher publisher)
        {
            if(publisher!=null)
            {
                try
                {
                    var entity = db.Publishers.SingleOrDefault(x => x.PubId == publisher.PubId);
                    if(entity.PubId>0)
                    {
                        if (!string.IsNullOrEmpty(publisher.PubName))
                        {
                            entity.PubName = publisher.PubName;
                        }
                        if (!string.IsNullOrEmpty(publisher.Description))
                        {
                            entity.Description = publisher.Description;
                        }

                        db.SaveChanges();
                        return true;
                    }
                }
                catch
                {

                }
            }
            return false;
        }
        
    }
}
