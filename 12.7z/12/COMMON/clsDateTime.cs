﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMMON
{
    public static class clsDateTime
    {
        public static string toString()
        {
            string datetime = DateTime.Now.ToString();
            string result = "";
            char[] character =
            {
                ' ',
                '/',
                ':',
                'S',
                'A',
                'C',
                'H',
                's',
                'a',
                'c',
                'h',
                'p',
                'm'
            };
            foreach(char i in datetime)
            {
                if(!character.Contains(i))
                {
                    result += i.ToString();
                }
            }
            return result;
        }
    }
}
