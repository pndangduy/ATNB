﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class Book
    {
        public int BookId { get; set; }
        public string Title { get; set; }
        public int CateId { get; set; }
        public string CateName { get; set; }
        public int AuthorId { get; set; }
        public string AuthorName { get; set; }
        public int PubId { get; set; }
        public string PubName { get; set; }
        public string Summary { get; set; }
        public string ImageUrl { get; set; }
        public double Price { get; set; }
        public int Quantity { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public bool IsActive { get; set; }
        
        public List<Comment> Comments { get; set; }
    }
}
