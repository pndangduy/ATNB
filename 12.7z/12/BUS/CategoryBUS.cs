﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAO;
using DTO;

namespace BUS
{
    public class CategoryBUS
    {
        CategoryDAO categoryDAO = null;
        public CategoryBUS()
        {
            categoryDAO = new CategoryDAO();
        }



        // Get list
        public List<Category> GetList()
        {
            return categoryDAO.GetList();
        }



        // Add
        public int Add(Category category)
        {
            return categoryDAO.Add(category);
        }



        // Remove
        public bool Remove(int categoryId)
        {
            return categoryDAO.Remove(categoryId);
        }



        //Edit
        public bool Edit(Category category)
        {
            return categoryDAO.Edit(category);
        }
    }
}
