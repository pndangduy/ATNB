﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAO;
using DTO;

namespace BUS
{
    public class AuthorBUS
    {
        AuthorDAO authorDAO = null;
        public AuthorBUS()
        {
            authorDAO = new AuthorDAO();
        }



        // Get list
        public List<Author> GetList()
        {
            return authorDAO.GetList();
        }



        // Add
        public int Add(Author author)
        {
            return authorDAO.Add(author);
        }



        // Remove
        public bool Remove(int authorId)
        {
            return authorDAO.Remove(authorId);
        }



        // Edit
        public bool Edit(Author author)
        {
            return authorDAO.Edit(author);
        }
    }
}
