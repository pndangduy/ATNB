﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAO;
using DTO;

namespace BUS
{
    public class BookBUS
    {
        BookDAO bookDAO = null;
        public BookBUS()
        {
            bookDAO = new BookDAO();
        }



        // Get list
        public List<DTO.Book> GetList()
        {
            return bookDAO.GetList();
        }



        // Add new book
        public bool Add(Book book)
        {
            return bookDAO.Add(book);
        }



        // Info
        public Book Info(int bookid)
        {
            return bookDAO.Info(bookid);
        }



        // Delete
        public bool Delete(int bookid)
        {
            return bookDAO.Delete(bookid);
        }


        // Active
        public bool Active(int bookid)
        {
            return bookDAO.Active(bookid);
        }
    }
}
