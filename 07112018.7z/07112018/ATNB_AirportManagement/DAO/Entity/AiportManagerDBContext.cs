namespace DAO.Entity
{
	using System;
	using System.Data.Entity;
	using System.ComponentModel.DataAnnotations.Schema;
	using System.Linq;

	public partial class AiportManagerDBContext : DbContext
	{
		public AiportManagerDBContext()
			: base("name=AiportManagerDBConnection")
		{
		}

		public virtual DbSet<Airport> Airports { get; set; }
		public virtual DbSet<FixedWing> FixedWings { get; set; }
		public virtual DbSet<FW_Type> FW_Type { get; set; }
		public virtual DbSet<Helicopter> Helicopters { get; set; }

		protected override void OnModelCreating(DbModelBuilder modelBuilder)
		{
			modelBuilder.Entity<Airport>()
				.Property(e => e.RunawaySize)
				.HasPrecision(18, 0);

			modelBuilder.Entity<Airport>()
				.HasMany(e => e.FixedWings)
				.WithRequired(e => e.Airport)
				.WillCascadeOnDelete(false);

			modelBuilder.Entity<Airport>()
				.HasMany(e => e.Helicopters)
				.WithRequired(e => e.Airport)
				.WillCascadeOnDelete(false);

			modelBuilder.Entity<FixedWing>()
				.Property(e => e.CruiseSpeed)
				.HasPrecision(18, 0);

			modelBuilder.Entity<FixedWing>()
				.Property(e => e.EmptyWeight)
				.HasPrecision(18, 0);

			modelBuilder.Entity<FixedWing>()
				.Property(e => e.MaxTakeOffWeight)
				.HasPrecision(18, 0);

			modelBuilder.Entity<FixedWing>()
				.Property(e => e.MinRunAwaySize)
				.HasPrecision(18, 0);

			modelBuilder.Entity<Helicopter>()
				.Property(e => e.CruiseSpeed)
				.HasPrecision(18, 0);

			modelBuilder.Entity<Helicopter>()
				.Property(e => e.EmtyWeight)
				.HasPrecision(18, 0);

			modelBuilder.Entity<Helicopter>()
				.Property(e => e.MaxTakeOffWeight)
				.HasPrecision(18, 0);

			modelBuilder.Entity<Helicopter>()
				.Property(e => e.Range)
				.HasPrecision(18, 0);
		}
	}
}
