﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
	public class ListPlane
	{
		public string Id { get; set; }
		public string  Model { get; set; }
		public string  FW_TypeID { get; set; }
		public decimal CruiseSpeed { get; set; }
		public decimal  EmptyWeight { get; set; }
		public decimal Maxweight { get; set; }
		public decimal MinRunway { get; set; }
		public decimal Range { get; set; }
		public string FlyMethod { get; set; }
		public string Airport_Id { get; set; }

	}
}
