﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
	/// <summary>
	/// instance class fixedwings inheritance class plane
	/// include properties from Plane class and 2 new properties: fixed wings type Id, Min runway
	/// </summary>
	public class FixedWings:Plane
	{
		//Fixed wing Id
		public string FixedWing_ID { get; set; }
	    // type ID
		public string  FWTypeID { get; set; }
		// min runway
		public double MinRunway { get; set; }

		public string Airport_ID { get; set; }
										   //airport
		public Airports Airport { get; set; }
		public FWType FWType { get; set; }
	}
}
