﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
	public class ListPlane
	{
		
		public string Airport_Id { get; set; }
		public string FixwedwingId { get; set; }
		public string HelicopterId{ get; set; }
		

	}
}
