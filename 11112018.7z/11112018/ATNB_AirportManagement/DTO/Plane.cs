﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
	/// <summary>
	/// intance class Plane is base class for fixed wings and helicopter
	/// properties:Id, Model, Cruise speed, Empty weight, Max take off weight, fly method 
	/// </summary>
	public class Plane
	{
	
		//model
		public string Model { get; set; }
		//cruise speed
		public double CruiseSpeed { get; set; }
		//empty weight
		public double EmtyWeight { get; set; }
		//max take off weight
		public double MaxTakeOffWeight { get; set; }
		//fly method
		public string FlyMethod { get; set; }
		//airport id
		
	}
}
