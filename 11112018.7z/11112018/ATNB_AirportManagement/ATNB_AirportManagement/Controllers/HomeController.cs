﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.OleDb;
using System.IO;
using BUS;
using System.Web.Mvc;

namespace ATNB_AirportManagement.Controllers
{
    public class HomeController : Controller
    {

        SqlConnection SqlConn = new SqlConnection("Data Source=DELL\\SQLEXPRESS;Initial Catalog=AirportManagement;Integrated Security=True");

        OleDbConnection OleConn;

        // GET: Home

        public ActionResult Index()
        {
            
            return View();
        }
        [HttpPost]
        public ActionResult Index(HttpPostedFileBase file)

        {
            ImportData import = new ImportData();


            string filename = Guid.NewGuid() + Path.GetExtension(file.FileName);
            string filepath = Server.MapPath("/excelfolder/" + filename);
            file.SaveAs(Path.Combine(Server.MapPath("/excelfolder"), filename));
            import.Import_DataAriport(filepath, filename,SqlConn,OleConn);
            import.Import_DataFW(filepath, filename, SqlConn, OleConn);
            import.Import_DataHelicopter(filepath,filename, SqlConn, OleConn);
            return View();

        }
    }
}