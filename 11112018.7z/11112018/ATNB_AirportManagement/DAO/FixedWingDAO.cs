﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
using DAO;

namespace DAO
{
	public class FixedWingDAO 
	{
		Entity.AirportDBContext db = null;
		public FixedWingDAO()
		{
			db = new Entity.AirportDBContext();
		}

		public string Add(Entity.FixedWing entity)
		{
			if(entity == null)
			{
				throw new NullReferenceException();

			}
			else
			{
				Entity.FixedWing plane = new Entity.FixedWing();
				try
				{
					plane.FW_ID=entity.FW_ID;
					plane.Model = entity.Model; 
					plane.CruiseSpeed = entity.CruiseSpeed;
					plane.EmptyWeight= entity.EmptyWeight;
					plane.MaxTakeOffWeight = entity.MaxTakeOffWeight;
					plane.MinRunAwaySize = entity.MinRunAwaySize;
					plane.Type_ID = entity.Type_ID;
					plane.FlyMethod = entity.FlyMethod;
					plane.Airport_ID = entity.Airport_ID;

					db.FixedWings.Add(plane);
					db.SaveChanges();
					return plane.FW_ID;
				}
				catch
				{ }
			}
			return null;
		}

		public bool Delete(string  Id)
		{
			if (Id==null)
			{
				throw new NullReferenceException();
			}
			else
			{
				try
				{
					var plane = db.FixedWings.SingleOrDefault(x => x.FW_ID == Id);
					db.FixedWings.Remove(plane);
					db.SaveChanges();
					return true;

				}
				catch { }
			}
			return false;
		}

		

		public bool Edit(Entity.FixedWing fixedwing)
		{
			if (fixedwing!= null)
			{
				try
				{
					var plane = db.FixedWings.SingleOrDefault(x => x.FW_ID ==fixedwing.FW_ID);
					if (plane.FW_ID != null)
					{
						if (!string.IsNullOrEmpty(fixedwing.Model))
						{
							plane.Model=fixedwing.Model;
						}
						if (!string.IsNullOrEmpty(fixedwing.Type_ID))
						{
							plane.Type_ID = fixedwing.Type_ID;
						}
						if (fixedwing.CruiseSpeed>0)
						{
							plane.CruiseSpeed = fixedwing.CruiseSpeed;
						}
						if (fixedwing.EmptyWeight > 0)
						{
							plane.EmptyWeight = fixedwing.EmptyWeight;
						}
						if (fixedwing.MaxTakeOffWeight > 0)
						{
							plane.MaxTakeOffWeight= fixedwing.MaxTakeOffWeight;
						}
						if (fixedwing.MinRunAwaySize > 0)
						{
							plane.MinRunAwaySize = fixedwing.MinRunAwaySize;
						}
						if (!string.IsNullOrEmpty(fixedwing.FlyMethod))
						{
							plane.FlyMethod = fixedwing.FlyMethod;
						}
						if (!string.IsNullOrEmpty(fixedwing.Airport_ID))
						{
							plane.Airport_ID = fixedwing.Airport_ID;
						}
						db.SaveChanges();
						return true;
					}
				}
				catch { }
			}
			return false;
		}

		public List<Entity.FixedWing> GetAllList()
		{
			var model = (from fixedwing in db.FixedWings
						 select new Entity.FixedWing()
						 {
							 FW_ID = fixedwing.FW_ID,
							 Model = fixedwing.Model,
							 Type_ID = fixedwing.Type_ID,
							 EmptyWeight = fixedwing.EmptyWeight ?? 0,
							 MaxTakeOffWeight = fixedwing.MaxTakeOffWeight ?? 0,
							MinRunAwaySize = fixedwing.MinRunAwaySize ?? 0,
							 FlyMethod = fixedwing.FlyMethod,
							 Airport_ID = fixedwing.Airport_ID
						 }).ToList();
			return model;
		}

		public List<Entity.FixedWing> GetByID(string ID)
		{
			var model = (from fixedwing in db.FixedWings
						 where fixedwing.Airport_ID == ID
						 select new Entity.FixedWing()
						 {
							FW_ID = fixedwing.FW_ID,
							 Model = fixedwing.Model,
							 Type_ID = fixedwing.Type_ID,
							 EmptyWeight = fixedwing.EmptyWeight??0,
							 MaxTakeOffWeight = fixedwing.MaxTakeOffWeight ?? 0,
							 MinRunAwaySize = fixedwing.MinRunAwaySize ?? 0,
							 FlyMethod = fixedwing.FlyMethod,
							 Airport_ID = fixedwing.Airport_ID
						 }).ToList();
			return model;
		}
		
	}
}
