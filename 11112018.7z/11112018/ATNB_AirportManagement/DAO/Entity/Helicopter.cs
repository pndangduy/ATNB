namespace DAO.Entity
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Helicopter")]
    public partial class Helicopter
    {
        [Key]
        [StringLength(7)]
        public string Helicopter_ID { get; set; }

        [StringLength(40)]
        public string Model { get; set; }

        public double? CruiseSpeed { get; set; }

        public double? EmtyWeight { get; set; }

        public double? MaxTakeOffWeight { get; set; }

        public double? Range { get; set; }

        [StringLength(50)]
        public string FlyMethod { get; set; }

        public bool? IsActive { get; set; }

        [Required]
        [StringLength(7)]
        public string Airport_ID { get; set; }

        public virtual Airport Airport { get; set; }
    }
}
