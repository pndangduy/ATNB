namespace DAO.Entity
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class FixedWing
    {
        [Key]
        [StringLength(7)]
        public string FW_ID { get; set; }

        [StringLength(40)]
        public string Model { get; set; }

        public double? CruiseSpeed { get; set; }

        public double? EmptyWeight { get; set; }

        public double? MaxTakeOffWeight { get; set; }

        public double? MinRunAwaySize { get; set; }

        [StringLength(50)]
        public string FlyMethod { get; set; }

        [StringLength(3)]
        public string Type_ID { get; set; }

        public bool? IsActive { get; set; }

        [Required]
        [StringLength(7)]
        public string Airport_ID { get; set; }

        public virtual Airport Airport { get; set; }

        public virtual FWType FWType { get; set; }
    }
}
