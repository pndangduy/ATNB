namespace DAO.Entity
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class AirportDBContext : DbContext
    {
        public AirportDBContext()
            : base("name=AirportDBConnection")
        {
        }

        public virtual DbSet<Airport> Airports { get; set; }
        public virtual DbSet<FixedWing> FixedWings { get; set; }
        public virtual DbSet<FWType> FWTypes { get; set; }
        public virtual DbSet<Helicopter> Helicopters { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Airport>()
                .HasMany(e => e.FixedWings)
                .WithRequired(e => e.Airport)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Airport>()
                .HasMany(e => e.Helicopters)
                .WithRequired(e => e.Airport)
                .WillCascadeOnDelete(false);
        }
    }
}
