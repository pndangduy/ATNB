namespace DAO.Entity
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Airport")]
    public partial class Airport
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Airport()
        {
            FixedWings = new HashSet<FixedWing>();
            Helicopters = new HashSet<Helicopter>();
        }

        [Key]
        [StringLength(7)]
        public string Airport_ID { get; set; }

        [StringLength(100)]
        public string Name { get; set; }

        public int? MaxFWParkingPlace { get; set; }

        public int? MaxHelicopterParkingPlace { get; set; }

        public bool? IsActive { get; set; }

        public double? RunawaySize { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<FixedWing> FixedWings { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Helicopter> Helicopters { get; set; }
    }
}
