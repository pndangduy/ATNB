﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.OleDb;
using System.IO;

namespace BUS
{
    public class ImportData
    {
        


        
        public void Import_DataAriport(string fullpath,string filename,SqlConnection SqlConn,OleDbConnection OleConn)
        {
            string constr = string.Format(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=""Excel 12.0 Xml;HDR=YES;""",fullpath);
            OleConn = new OleDbConnection(constr);
            
            string query = string.Format("Select * from [Sheet1$]");
            OleDbCommand Ecom = new OleDbCommand(query, OleConn);
            OleConn.Open();
            DataSet ds = new DataSet();
            OleDbDataAdapter oda = new OleDbDataAdapter(query, OleConn);
            OleConn.Close();

            oda.Fill(ds);

            DataTable dt = ds.Tables[0];
            SqlBulkCopy objbulk = new SqlBulkCopy(SqlConn);

            objbulk.DestinationTableName = "Airport";
            objbulk.ColumnMappings.Add("Airport_ID", "Airport_ID");
            objbulk.ColumnMappings.Add("Name", "Name");
            objbulk.ColumnMappings.Add("MaxFWParkingPlace", "MaxFWParkingPlace");
            objbulk.ColumnMappings.Add("MaxHelicopterParkingPlace", "MaxHelicopterParkingPlace");
            objbulk.ColumnMappings.Add("IsActive", "IsActive");
            objbulk.ColumnMappings.Add("RunawaySize", "RunawaySize");
            SqlConn.Open();
            objbulk.WriteToServer(dt);
            SqlConn.Close();
        }
        public void Import_DataFW(string fullpath, string filename, SqlConnection SqlConn, OleDbConnection OleConn)
        {
            string constr = string.Format(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=""Excel 12.0 Xml;HDR=YES;""", fullpath);
            OleConn = new OleDbConnection(constr);
            string query = string.Format("Select * from [Sheet1$]");
            OleDbCommand Ecom = new OleDbCommand(query, OleConn);
            OleConn.Open();
            DataSet ds = new DataSet();
            OleDbDataAdapter oda = new OleDbDataAdapter(query, OleConn);
            OleConn.Close();

            oda.Fill(ds);

            DataTable dt = ds.Tables[0];
            SqlBulkCopy objbulk = new SqlBulkCopy(SqlConn);
            objbulk.DestinationTableName = "FixedWings";
            objbulk.ColumnMappings.Add("FW_ID", "FW_ID");
            objbulk.ColumnMappings.Add("Model", "Model");
            objbulk.ColumnMappings.Add("CruiseSpeed", "CruiseSpeed");
            objbulk.ColumnMappings.Add("EmptyWeight", "EmptyWeight");
            objbulk.ColumnMappings.Add("MaxTakeOffWeight", "MaxTakeOffWeight");
            objbulk.ColumnMappings.Add("MinRunAwaySize", "MinRunAwaySize");
            objbulk.ColumnMappings.Add("FlyMethod", "FlyMethod");
            objbulk.ColumnMappings.Add("Type_ID", "Type_ID");
            objbulk.ColumnMappings.Add("IsActive", "IsActive");
            objbulk.ColumnMappings.Add("Airport_ID", "Airport_ID");
            SqlConn.Open();
            objbulk.WriteToServer(dt);
            SqlConn.Close();
        }
        public void Import_DataHelicopter(string fullpath, string filename, SqlConnection SqlConn, OleDbConnection OleConn)
        {
            string constr = string.Format(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=""Excel 12.0 Xml;HDR=YES;""", fullpath);
            OleConn = new OleDbConnection(constr);
            string query = string.Format("Select * from [Sheet1$]");
            OleDbCommand Ecom = new OleDbCommand(query, OleConn);
            OleConn.Open();
            DataSet ds = new DataSet();
            OleDbDataAdapter oda = new OleDbDataAdapter(query, OleConn);
            OleConn.Close();

            oda.Fill(ds);

            DataTable dt = ds.Tables[0];
            SqlBulkCopy objbulk = new SqlBulkCopy(SqlConn);
            objbulk.DestinationTableName = "Helicopter";
            objbulk.ColumnMappings.Add("Helicopter_ID", "Helicopter_ID");
            objbulk.ColumnMappings.Add("Model", "Model");
            objbulk.ColumnMappings.Add("CruiseSpeed", "CruiseSpeed");
            objbulk.ColumnMappings.Add("EmtyWeight", "EmtyWeight");
            objbulk.ColumnMappings.Add("MaxTakeOffWeight", "MaxTakeOffWeight");
            objbulk.ColumnMappings.Add("Range", "Range");
            objbulk.ColumnMappings.Add("FlyMethod", "FlyMethod");
            objbulk.ColumnMappings.Add("IsActive", "IsActive");
            objbulk.ColumnMappings.Add("Airport_ID", "Airport_ID");
            SqlConn.Open();
            objbulk.WriteToServer(dt);
            SqlConn.Close();
        }
    }
}
