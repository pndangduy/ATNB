﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
	/// <summary>
	/// intance class airport with properties: ID, Name, Runway size, max fixed wings parking place,max helicopter parking place, list of fixed wings, list of helicopter
	/// </summary>
	public class Airports
	{
		//ID
		public string Airport_ID { get; set; }
		//Name
		public string Name { get; set; }
		//Run way size
		public double RunwaySize { get; set; }
		// Max parking place for fixed wings
		public int MaxFWParkingPlace { get; set; }
		//Max parking place for helicopter
		public int MaxHelicopterParkingPlace { get; set; }
		//list of fixed wings
		//public string FixedWing_ID { get; set; }
		public List<FixedWings> List_FW { get; set; }
		//list of helicopter
		public List<Helicopters> List_Helicopter { get; set; }
		//public string Helicopter_ID { get; set; }
	}
}
