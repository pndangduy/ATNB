﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;


namespace DAO
{
    public class HelicopterDAO
    {
		private const float times = 1.5f;
        EF.AirportDbContext db;
        public HelicopterDAO()
        {
            db = new EF.AirportDbContext();
        }



        // Add
        public string Add(Helicopter helicopter)
        {
            try
            {
                EF.Helicopter entity = new EF.Helicopter();

                entity.HelecopterID = helicopter.PlaneID;
                entity.Model = helicopter.Model;
                entity.CruiseSpeed = helicopter.CruiseSpeed;
                entity.EmptyWeight = helicopter.EmptyWeight;
                entity.MaxTakeOffWeight = helicopter.MaxTakeOffWeight;
                entity.Rang = helicopter.Range;
                entity.FlyMethod = helicopter.FlyMethod;
                entity.AirPortID = null;

                db.Helicopters.Add(entity);
                db.SaveChanges();

                return entity.HelecopterID;
            }
            catch
            {
                return null;
            }
        }
		public List<DTO.Helicopter> GetALLList()
		{
			try
			{
				var model = (from helicopter in db.Helicopters
							 where helicopter.IsActive==false

							 select new Helicopter()
							 {
								 PlaneID = helicopter.HelecopterID,
								 Model = helicopter.Model,
								 CruiseSpeed = helicopter.CruiseSpeed ?? 0,
								 EmptyWeight = helicopter.EmptyWeight ?? 0,
								 MaxTakeOffWeight = helicopter.MaxTakeOffWeight ?? 0,
								 FlyMethod = helicopter.FlyMethod ?? 0,
								 Range = helicopter.Rang ?? 0,
								 AirportId = helicopter.AirPortID
							 }).ToList();
				return model;
			}
			catch
			{
				return null;
			}
		}



		// parking
		public bool Parking(string helicopterID,string airportID)
        {
            try
            {
                var entity = db.Helicopters.SingleOrDefault(x => x.HelecopterID == helicopterID);
                entity.AirPortID = airportID;
                db.SaveChanges();
                return true;
            }
            catch { }
            return false;
        }



        // Remove
        // Edit
        // Info
        public Helicopter Info(string helicopterID)
        {
            try
            {
                var model = (from helicopter in db.Helicopters
                             join airport in db.AirPorts
                             on helicopter.AirPortID equals airport.AirportID
							 where helicopter.HelecopterID==helicopterID
                             select new Helicopter()
                             {
                                 PlaneID = helicopter.HelecopterID,
                                 Model = helicopter.Model,
                                 CruiseSpeed = helicopter.CruiseSpeed ?? 0,
                                 EmptyWeight = helicopter.EmptyWeight ?? 0,
                                 MaxTakeOffWeight = helicopter.MaxTakeOffWeight ?? 0,
                                 FlyMethod = helicopter.FlyMethod ?? 0,
                                 Range = helicopter.Rang??0,
                                 AirportId = helicopter.AirPortID,
                                 AirportName = airport.AirportName
                             }).First();
                return model;
            }
            catch { }
            return null;
        }

		public bool Edit(string Helicopterid, double range, double Maxtakeoffweight)
		{
			try
			{
				var entity = db.Helicopters.SingleOrDefault(x => x.HelecopterID == Helicopterid);
				entity.Rang = range;
				if (Maxtakeoffweight > entity.EmptyWeight * times)
				{
					throw new Exception("Take off Weight not excess 1.5 *Emptyweight");

				}
				else
				{
					entity.MaxTakeOffWeight = Maxtakeoffweight;
				}

				db.SaveChanges();
				return true;
			}
			catch
			{
				return false;
			}
		}


		public List<DTO.Helicopter> GetALLListFree()
		{
			try
			{
				var model = (from helicopter in db.Helicopters
							 where helicopter.AirPortID==null

							 select new Helicopter()
							 {
								 PlaneID = helicopter.HelecopterID,
								 Model = helicopter.Model,
								 CruiseSpeed = helicopter.CruiseSpeed ?? 0,
								 EmptyWeight = helicopter.EmptyWeight ?? 0,
								 MaxTakeOffWeight = helicopter.MaxTakeOffWeight ?? 0,
								 FlyMethod = helicopter.FlyMethod ?? 0,
								 Range = helicopter.Rang ?? 0,
								 AirportId = helicopter.AirPortID
							 }).ToList();
				return model;
			}
			catch
			{
				return null;
			}
		}
		public bool RemoveHelicopter(string ID)
		{
			try
			{
				var efHelicopter = db.Helicopters.SingleOrDefault(x => x.HelecopterID ==ID);
				if (efHelicopter != null)
				{
					efHelicopter.AirPortID = null;
					db.SaveChanges();
					return true;
				}

				return false;
			}
			catch
			{
				return false;
			}
		}
	}
}
