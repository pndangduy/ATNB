﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
using DAO;

namespace BUS
{
    public class AirplaneBUS
    {
        AirPlaneDAO airplaneDAO;
        public AirplaneBUS()
        {
            airplaneDAO = new AirPlaneDAO();
        }



        // Import data
        public void ImportData(List<string> data)
        {
            if (data != null)
            {
                if (data.Count() > 0)
                {
                    foreach (var item in data)
                    {
                        var row = item.Split(',').ToList();
                        if (row.Count() > 0)
                        {
                            if (row[0].Trim().Substring(0, 2) == "FW" || row[0].Trim().Substring(0, 2) == "fw")
                            {
                                string airplaneid = row[0].Trim();
                                string model = row[1].Trim();
                                double cruisespeed = double.Parse(row[3]);
                                double emptyweight = double.Parse(row[4]);
                                double maxtakeoffweight = double.Parse(row[5]);
                                int flymethod = int.Parse(row[7]);
                                double minrunwaysize = double.Parse(row[6]);
                                int airplanetype = airplaneDAO.getAirplaneTypeId(row[2].Trim());

                                if(!string.IsNullOrEmpty(airplaneid) && !string.IsNullOrEmpty(model) && minrunwaysize>0)
                                {
                                    AirPlane airplane = new AirPlane(airplaneid, model, cruisespeed, emptyweight, maxtakeoffweight, flymethod, minrunwaysize, airplanetype);
                                    Add(airplane);
                                }
                            }
                        }
                    }
                }
            }
        }



        // Add
        public string Add(AirPlane airplane)
        {
            return airplaneDAO.Add(airplane);
        }



        // Paking
        public bool Paking(string airplaneID, string airportID)
        {
            return airplaneDAO.Parking(airplaneID, airportID);
        }



        // Info
        public AirPlane Info(string airplaneID)
        {
            return airplaneDAO.Info(airplaneID);
        }



        // Get list
        public List<AirPlane> GetList(double runwaysize)
        {
            return airplaneDAO.GetList(runwaysize);
        }
		public List<AirPlane> GetALLList()
		{
			return airplaneDAO.GetALLList();
		}


        // Edit
        public bool Edit(string airplaneid, int airplanetype, double minrunway)
        {
            return airplaneDAO.Edit(airplaneid, airplanetype, minrunway);
        }



        // get list of airplane type
        public List<AirPlaneType> GetListAirPlaneType()
        {
            return airplaneDAO.GetListAirPlaneType();
        }
		public List<AirPlane> GettAllListFree()
		{
			return airplaneDAO.GetALLListFree();
		}
		public bool RemoveAirplane(string ID)
		{
			return airplaneDAO.RemoveAirplane(ID);
		}
    }
}
