﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    /// <summary>
    /// 05112078-1411
    /// class: Air plane type
    /// Defind three type of fixed wing plane is: CAG(Cargo), LGR(Long range) and PRV(Private)
    /// </summary>
    public class AirPlaneType
    {
        // CAG(Cargo), LGR(Long range) and PRV(Private)
        public int AirplaneTypeId { get; set; }
        // Name of Fixed wing plane type
        public string AirplaneTypeName { get; set; }
    }
}
