﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace AirPort_Manager.Models
{
	public class EditHelicopter
	{
		[Key]
		public string HelicopterId { get; set; }

		[Required]
		public double Range{ get; set; }

		[Required]
		public double MaxTakeOffWeight { get; set; }
	}
}