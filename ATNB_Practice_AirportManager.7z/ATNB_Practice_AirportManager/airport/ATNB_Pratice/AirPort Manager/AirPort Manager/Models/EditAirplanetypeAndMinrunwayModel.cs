﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace AirPort_Manager.Models
{
    public class EditAirplanetypeAndMinrunwayModel
    {
        [Key]
        public string AirplaneId { get; set; }

        [Required]
        public int AirplaneTypeId { get; set; }

        [Required]
        public double MinRunway { get; set; }
    }
}