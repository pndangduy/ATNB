﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using DTO;


namespace AirPort_Manager.Models
{
    public class AddAirportModel
    {
        [Display(Name ="Airport ID, system will create id automatically if you not input airport ID")]
        public string AirportId { get; set; }

        [Display(Name ="Airport name")]
        [Required]
        public string AirportName { get; set; }

        [Display(Name ="Runway size")]
        [Required]
        public double RunwaySize { get; set; }

        [Display(Name ="Max paking place for airplane")]
        [Required]
        public int MaxAirplanePakingPlace { get; set; }

        [Display(Name ="Max paking place for helicopter")]
        [Required]
        public int MaxHelicopterPakingPlace { get; set; }
		
		public IEnumerable<AirPlane> ListAirplane { get; set; }
		public IEnumerable<Helicopter> ListHelicopter { get; set; }

    }
}