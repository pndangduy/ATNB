﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace AirPort_Manager.Models
{
    public class ImportData
    {
        [Required]
        public HttpPostedFileBase File { get; set; }
    }
}