﻿namespace ATNB.Service.Abstractions
{
    public interface IService
    {
    }
}
