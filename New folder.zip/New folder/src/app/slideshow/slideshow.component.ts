import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slideshow',
  templateUrl: './slideshow.component.html',
  styleUrls: ['./slideshow.component.css']
})
export class SlideshowComponent implements OnInit {

  Images = [
    new Image ( 1, 'http://baoveyuki.com.vn/images/ximg02.jpg.pagespeed.ic.v42COu0uPc.webp'),
    new Image ( 2, 'http://baoveyuki.com.vn/images/ximg01.jpg.pagespeed.ic.5qtYkv9F1P.webp'),
    new Image ( 3, 'http://baoveyuki.com.vn/images/ximg01.jpg.pagespeed.ic.5qtYkv9F1P.webp'),
    new Image ( 4, 'http://baoveyuki.com.vn/images/ximg01.jpg.pagespeed.ic.5qtYkv9F1P.webp'),
    new Image ( 5, 'http://baoveyuki.com.vn/images/ximg01.jpg.pagespeed.ic.5qtYkv9F1P.webp'),
    new Image ( 6, 'http://baoveyuki.com.vn/images/ximg01.jpg.pagespeed.ic.5qtYkv9F1P.webp'),
    new Image ( 7, 'http://baoveyuki.com.vn/images/ximg01.jpg.pagespeed.ic.5qtYkv9F1P.webp'),
    new Image ( 8, 'http://baoveyuki.com.vn/images/ximg01.jpg.pagespeed.ic.5qtYkv9F1P.webp'),
    new Image ( 9, 'http://baoveyuki.com.vn/images/ximg01.jpg.pagespeed.ic.5qtYkv9F1P.webp'),
    new Image ( 10, 'http://baoveyuki.com.vn/images/ximg01.jpg.pagespeed.ic.5qtYkv9F1P.webp')
  ];

  constructor() { }

  ngOnInit() {
  }

}

export class Image {
  id: number;
  link: string;

  constructor(id, link) {
    this.id = id;
    this.link = link;
  }
}
