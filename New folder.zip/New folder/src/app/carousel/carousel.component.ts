import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.css']
})
export class CarouselComponent implements OnInit {

  Images = [
    new Image ( 1, './assets/image/carousel1.png'),
    new Image ( 2, './assets/image/carousel2.png'),
    new Image ( 3, './assets/image/carousel3.png'),
    new Image ( 4, './assets/image/carousel4.png'),
    new Image ( 5, './assets/image/carousel5.png')
  ];

  constructor() { }

  ngOnInit() {
  }

}

// defind image class
export class Image {
  id: number;
  src: string;

  constructor(id, src) {
    this.id = id;
    this.src = src;
  }
}
