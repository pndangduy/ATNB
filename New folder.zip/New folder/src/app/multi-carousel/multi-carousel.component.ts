
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-multi-carousel',
  templateUrl: './multi-carousel.component.html',
  styleUrls: ['./multi-carousel.component.css']
})
export class MultiCarouselComponent implements OnInit {

  timeLeft = 60;
  interval;

  Images = [
    new Image ( 1, './assets/image/carousel1.png'),
    new Image ( 2, './assets/image/carousel2.png'),
    new Image ( 3, './assets/image/carousel3.png'),
    new Image ( 4, './assets/image/carousel4.png'),
    new Image ( 5, './assets/image/carousel5.png')
  ];



  constructor() { }

  ngOnInit() {
    this.autoRun();
  }

  changeImage() {
    this.Images.push(this.Images.shift());
  }

  autoRun() {
    this.interval = setInterval(() => {
      this.changeImage();
    }, 3000);
  }

}

// defind image class
export class Image {
  id: number;
  src: string;

  constructor(id, src) {
    this.id = id;
    this.src = src;
  }
}
