import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-social-bar',
  templateUrl: './social-bar.component.html',
  styleUrls: ['./social-bar.component.css']
})
export class SocialBarComponent implements OnInit {

  Socials = [
    new Social ('Mail', '#', 'fa fa-envelope'),
    new Social ('Facebook', '#', 'fa fa-facebook-f'),
    new Social ('Twitter', '#', 'fa fa-twitter'),
    new Social ('Linkedin', '#', 'fa fa-linkedin'),
    new Social ('Google +', '#', 'fa fa-google-plus'),
    new Social ('Youtube', '#', 'fa fa-youtube')
  ];

  constructor() { }

  ngOnInit() {
  }

}

export class Social {
  name: '';
  link: '';
  icon: '';

  constructor(name, link, icon) {
    this.name = name;
    this.link = link;
    this.icon = icon;
  }
}
