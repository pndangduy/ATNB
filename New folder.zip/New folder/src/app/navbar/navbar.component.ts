import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  MenuItems = [
    new MenuItem (1, 'Trang chủ'),
    new MenuItem (2, 'Điểm nổi bật'),
    new MenuItem (3, 'Dịch vụ'),
    new MenuItem (4, 'Khách hàng'),
    new MenuItem (5, 'Cơ cấu tổ chức'),
    new MenuItem (6, 'Tin tức'),
    new MenuItem (7, 'Liên hệ')
  ];

  constructor() { }

  ngOnInit() {
  }

}


// defind class MenuItem
export class MenuItem {
  id: 0;
  name: '';

  constructor(id, name) {
    this.id = id;
    this.name = name;
  }
}
