﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAO;
using DTO;


namespace BUS
{
    public class UserBUS
    {
        UserDAO userDAO = null;
        public UserBUS()
        {
            userDAO = new UserDAO();
        }



        // Login
        public int Login(string username, string password)
        {
            return userDAO.Login(username, password);
        }



        // Get List
        public List<User> GetList()
        {
            return userDAO.GetList();
        }



        // Add
        public bool Add(User user)
        {
            return userDAO.Add(user);
        }
    }
}
