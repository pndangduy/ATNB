﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAO;
using DTO;

namespace BUS
{
    public class PublisherBUS
    {
        PublisherDAO publisherDAO = null;
        public PublisherBUS()
        {
            publisherDAO = new PublisherDAO();
        }



        // Get list
        public List<Publisher> GetList()
        {
            return publisherDAO.GetList();
        }



        // Add
        public bool Add(Publisher publisher)
        {
            return publisherDAO.Add(publisher);
        }





        // Edit
        public bool Edit(Publisher publisher)
        {
            return publisherDAO.Edit(publisher);
        }
    }
}
