﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class Category
    {
        public int CateId { get; set; }
        public string CateName { get; set; }
        public string Description { get; set; }
    }
}
