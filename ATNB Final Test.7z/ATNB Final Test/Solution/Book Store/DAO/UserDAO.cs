﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAO;
using DTO;

namespace DAO
{
    public class UserDAO
    {
        EF.BookStoreDbContext db = null;
        public UserDAO()
        {
            db = new EF.BookStoreDbContext();
        }



        // Login
        public int Login(string username, string password)
        {
            if(!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password))
            {
                try
                {
                    if(!string.IsNullOrEmpty(db.Users.SingleOrDefault(x=>x.UserName==username && x.Password==password).UserName))
                    {
                        return 1;
                    }
                    else
                    {
                        if(!string.IsNullOrEmpty(db.Users.SingleOrDefault(x => x.UserName == username).UserName))
                        {
                            return -1;
                        }
                    }
                }
                catch { }
            }
            return 0;
        }



        // Get List
        public List<User> GetList()
        {
            var model = (from user in db.Users
                         select new User()
                         {
                             UserName = user.UserName,
                             Email = user.Email,
                             IsActive = user.IsActive
                         }).ToList();
            return model;
        }



        // Add
        public bool Add(User user)
        {
            if(user != null)
            {
                try
                {
                    EF.User entity = new EF.User();

                    entity.UserName = user.UserName;
                    entity.Password = user.Password;
                    entity.Email = user.Email;
                    entity.IsActive = user.IsActive;

                    db.Users.Add(entity);
                    db.SaveChanges();
                    return true;

                }
                catch { }
            }
            return false;
        }
    }
}
