﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BUS;

namespace BOOK_STORE.Controllers
{
    public class HomeController : Controller
    {
        BookBUS bookBUS = null;
        AuthorBUS authorBUS = null;
        CategoryBUS categoryBUS = null;
        public HomeController()
        {
            bookBUS = new BookBUS();
            authorBUS = new AuthorBUS();
            categoryBUS = new CategoryBUS();
        }


        public ActionResult Index()
        {
            return View(bookBUS.GetList());
        }


        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }



        [ChildActionOnly]
        public ActionResult _AuthorMenu()
        {
            return PartialView(authorBUS.GetList());
        }



        [ChildActionOnly]
        public ActionResult _CategoryMenu()
        {
            return PartialView(categoryBUS.GetList());
        }



        // Error Page
        public ActionResult Error()
        {
            return View();
        }
    }
}