﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BUS;
using DTO;

namespace BOOK_STORE.Controllers
{
    public class BookController : Controller
    {
        BookBUS bookBUS = null;
        public BookController()
        {
            bookBUS = new BookBUS();
        }



        public ActionResult Info(int Id)
        {
            return View(bookBUS.Info(Id));
        }
    }
}