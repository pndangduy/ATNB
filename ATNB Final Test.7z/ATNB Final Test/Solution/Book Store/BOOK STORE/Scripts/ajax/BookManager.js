﻿// Delete a book
function deleteBook(bookid) {
    var cf = confirm("Are you want to disable this book!");
    if (cf == true) {
        if (bookid == 0) {
            window.alert("Book is not exist!");
        }
        else {
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200 && this.responseText == "True") {
                    $("#tr" + bookid + " #btndelete").css("display", "none");
                    $("#tr" + bookid + " #btnactive").css("display", "unset");
                    window.alert("Delete book success!");
                }
            };
            xhttp.open("DELETE", "Delete?Id=" + bookid, true);
            xhttp.send();
        }
    }
}



// Active a book
function activeBook(bookid) {
    var cf = confirm("Are you want to active this book!");
    if (cf == true) {
        if (bookid == 0) {
            window.alert("Book Id is null");
        }
        else {
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200 && this.responseText == "True") {
                    $("#tr" + bookid + " #btndelete").css("display", "unset");
                    $("#tr" + bookid + " #btnactive").css("display", "none");
                    window.alert("Active book success!");
                }
            };
            xhttp.open("GET", "Active?Id=" + bookid, true);
            xhttp.send();
        }
    }  
}