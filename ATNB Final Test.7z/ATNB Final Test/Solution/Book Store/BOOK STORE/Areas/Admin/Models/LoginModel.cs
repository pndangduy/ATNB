﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace BOOK_STORE.Areas.Admin.Models
{
    public class LoginModel
    {
        [Display(Name ="User Name")]
        [Required]
        public string UserName { get; set; }

        [Display(Name ="Password")]
        [DataType(DataType.Password)]
        [Required]
        public string Password { get; set; }

        public bool RememberMe { get; set; }
    }
}