﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BUS;
using DTO;

namespace BOOK_STORE.Areas.Admin.Controllers
{
    public class CategoryManagerController : Controller
    {
        CategoryBUS categoryBUS = null;
        public CategoryManagerController()
        {
            categoryBUS = new CategoryBUS();
        }



        // Index
        public ActionResult Index()
        {
            return View(categoryBUS.GetList());
        }
    }
}