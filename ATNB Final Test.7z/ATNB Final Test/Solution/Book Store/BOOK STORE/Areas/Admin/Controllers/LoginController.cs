﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BOOK_STORE.Areas.Admin.Models;
using BUS;
using DTO;

namespace BOOK_STORE.Areas.Admin.Controllers
{
    public class LoginController : Controller
    {
        UserBUS userBUS = null;
        public LoginController()
        {
            userBUS = new UserBUS();
        }



        // Login
        [HttpGet]
        public ActionResult Index()
        {
            if (Session["UserName"] != null)
            {
                return RedirectToAction("Index", "Dashbord", new { area = "Admin" });
            }
            return View();
        }
        [HttpPost]
        public ActionResult Index(LoginModel model)
        {
            if (ModelState.IsValid)
            {
                int Result = userBUS.Login(model.UserName, model.Password);
                if (Result == 1)
                {
                    Session["UserName"] = model.UserName;
                    return RedirectToAction("Index", "Dashbord", new { area = "Admin" });
                }
                else
                {
                    if(Result==0)
                    {
                        ModelState.AddModelError("", "Account is not exist");
                    }
                    else
                    {
                        if (Result == -1)
                        {
                            ModelState.AddModelError("", "Password is wrong!");
                        }
                    }
                    
                }
            }
            return View();
        }



        // Logout
        public ActionResult Logout()
        {
            if (Session["UserName"]!=null)
            {
                Session["UserName"] = null;
            }
            return RedirectToAction("Index", "Login", new { area = "Admin" });
        }
    }
}