﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAO;
using DTO;

namespace BUS
{
    public class AirportBUS
    {
        AirportDAO airportDAO;
        AirPlaneDAO airplaneDAO;
        HelicopterDAO helicopterDAO;
        public AirportBUS()
        {
            airportDAO = new AirportDAO();
            airplaneDAO = new AirPlaneDAO();
            helicopterDAO = new HelicopterDAO();
        }



        // Import data
        public void ImportData(List<string> data)
        {
            if (data != null)
            {
                if (data.Count() > 0)
                {
                    foreach (var item in data)
                    {
                        var row = item.Split(',').ToList();
                        if (row.Count() > 0)
                        {
                            if (!string.IsNullOrEmpty(row[0]) && (row[0].Trim().Substring(0, 2) == "AP" || row[0].Trim().Substring(0, 2) == "ap") && !string.IsNullOrEmpty(row[1]))
                            {
                                string airportid = row[0].Trim();
                                string airportname = row[1].Trim();
                                double runwaysize = double.Parse(row[2]);
                                int maxairplanetakeparkplace = int.Parse(row[3]);
                                string lstofairplane = row[4].Trim();
                                List<string> listofairplane = lstofairplane.Split(' ').ToList();
                                int maxhelicoptertakeparkplace = int.Parse(row[5]);
                                string lstofhelicopter = row[6].Trim();
                                List<string> listofhelicopter = lstofhelicopter.Split(' ').ToList();

                                Airport airport = new Airport(airportid,airportname,runwaysize,maxairplanetakeparkplace,listofairplane,maxhelicoptertakeparkplace,listofhelicopter);
                                Add(airport);

                                if(listofairplane.Count()>0)
                                {
                                    foreach (var airplaneID in listofairplane)
                                    {
                                        airplaneDAO.Parking(airplaneID, airportid);
                                    }
                                }

                                if (listofhelicopter.Count() > 0)
                                {
                                    foreach (var helicopterID in listofhelicopter)
                                    {
                                        helicopterDAO.Parking(helicopterID, airportid);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }



        // Add
        public string Add(Airport airport)
        {
            return airportDAO.Add(airport);
        }



        // Get list
        public List<DTO.Airport> GetList()
        {
            return airportDAO.GetList();
        }



        // Info
        public DTO.Airport Info(string airportID)
        {
            return airportDAO.Info(airportID);
        }



        // Check exist
        public bool IsExist(string airportId)
        {
            return airportDAO.IsExist(airportId);
        }



        // Delete
        public bool Delete(string airportId)
        {
            return airportDAO.Delete(airportId);
        }
    }
}
