﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAO;
using DTO;

namespace BUS
{
    public class HelicopterBUS
    {
        HelicopterDAO helicopterDAO;
        public HelicopterBUS()
        {
            helicopterDAO = new HelicopterDAO();
        }



        // Add
        public string Add(Helicopter helicopter)
        {
            return helicopterDAO.Add(helicopter);
        }

		public List<DTO.Helicopter> GettAllListFree()
		{
			return helicopterDAO.GetALLListFree();
		}

        // Import data
        public void ImportData(List<string> data)
        {
            if (data != null)
            {
                if (data.Count() > 0)
                {
                    foreach (var item in data)
                    {
                        var row = item.Split(',').ToList();
                        if (row.Count() > 0)
                        {
                            if (!string.IsNullOrEmpty(row[0]) && (row[0].Trim().Substring(0, 2) == "RW" || row[0].Trim().Substring(0, 2) == "rw"))
                            {
                                string helicopterid = row[0].Trim();
                                string model = row[1].Trim();
                                double cruisespeed = double.Parse(row[2]);
                                double emptyweight = double.Parse(row[3]);
                                double maxtakeofweight = double.Parse(row[4]);
                                double range = double.Parse(row[5]);
                                int flymethod = int.Parse(row[6]);



                                Helicopter helicopter = new Helicopter(helicopterid, model, cruisespeed, emptyweight, maxtakeofweight, flymethod, range);
                                Add(helicopter);
                            }
                        }
                    }
                }
            }
        }



        // Paking
        public bool Paking(string helicopterID, string airportID)
        {
            return helicopterDAO.Parking(helicopterID, airportID);
        }



        // Info
        public Helicopter Info(string helicopterID)
        {
            return helicopterDAO.Info(helicopterID);
        }
		public bool Edit(string helicopterid, double  range, double takeoffweight)
		{
			return helicopterDAO.Edit(helicopterid, range,takeoffweight);
		}
		public List<Helicopter> GetALLList()
		{
			return helicopterDAO.GetALLList();
		}
	}
}
