﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BUS;
using DTO;
using COMMON;

namespace AirPort_Manager.Controllers
{
    public class AdminController :Controller
    {
        AirportBUS airportBUS = null;
        AirplaneBUS airplaneBUS = null;
        HelicopterBUS helicopterBUS = null;
        public AdminController()
        {
            airportBUS = new AirportBUS();
            airplaneBUS = new AirplaneBUS();
            helicopterBUS = new HelicopterBUS();
        }




        // GET: Admin
        public ActionResult Index()
        {
            return View();
        }



        //Import Data
       [HttpGet]
        public ActionResult ImportData()
        {
            return View();
        }
        [HttpPost]
        public ActionResult ImportData(AirPort_Manager.Models.ImportData model)
        {
            if(ModelState.IsValid)
            {
                try
                {
                    var data = COMMON.CSVFile.Read(model.File.InputStream);
                    airplaneBUS.ImportData(data);
                    helicopterBUS.ImportData(data);
                    airportBUS.ImportData(data);
                }
                catch { }
            }
            return View();
        }
    }
}