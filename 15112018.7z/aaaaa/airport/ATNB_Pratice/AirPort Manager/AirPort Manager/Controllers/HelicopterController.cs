﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BUS;
using DTO;
using AirPort_Manager.Models;

namespace AirPort_Manager.Controllers
{
    public class HelicopterController : Controller
    {
        HelicopterBUS helicopterBUS = null;
        public HelicopterController()
        {
            helicopterBUS = new HelicopterBUS();
        }

		public ActionResult Index()
		{
			var model =helicopterBUS.GetALLList();
			return View(model);
		}
		public ActionResult HelicopterNotParking()
		{
			var model = helicopterBUS.GettAllListFree();
			return View(model);
		}

        // Info
        public ActionResult Info(string Id)
        {
            var model = helicopterBUS.Info(Id);
            return View(model);
        }
		[HttpGet]
		public ActionResult Edit(string id)
		{
			EditHelicopter model = new EditHelicopter();
			model.HelicopterId = id;
			return View(model);
		}
		[HttpPost]
		public ActionResult Edit(EditHelicopter model)
		{
			if (ModelState.IsValid)
			{
				if (helicopterBUS.Edit(model.HelicopterId, model.Range, model.MaxTakeOffWeight))
				{
					return RedirectToAction("Index", "Airport");
				}
				else
				{
					ModelState.AddModelError("", "Have a problem, please check and try again!");
				}
			}
			return View();
		}
	}
}