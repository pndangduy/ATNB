﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BUS;
using DTO;
using AirPort_Manager.Models;

namespace AirPort_Manager.Controllers
{
    public class AirportController : Controller
    {
        AirportBUS airportBUS = null;
        public AirportController()
        {
            airportBUS = new AirportBUS();
        }



        // GET: Airport
        public ActionResult Index()
        {
            return View();
        }



        // Info
        public ActionResult Info(string Id)
        {
            var model = airportBUS.Info(Id);
            return View(model);
        }



        // Add
        [HttpGet]
        public ActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Add(AddAirportModel model)
        {
            if(ModelState.IsValid)
            {
                DTO.Airport airport = new Airport();
                if(!string.IsNullOrEmpty(model.AirportId))
                {
                    airport.AirportID = model.AirportId;
                }
                else
                {
                    CreateAirportID:
                    Random r = new Random();
                    airport.AirportID = "AP" + r.Next(10000, 99999).ToString();
                    if(airportBUS.IsExist(airport.AirportID))
                    {
                        goto CreateAirportID;
                    }
                }
                airport.AirportName = model.AirportName;
                airport.RunwaySize = model.RunwaySize;
                airport.MaxAirPlanePakingPlace = model.MaxAirplanePakingPlace;
                airport.MaxHelicopterPakingPlace = model.MaxHelicopterPakingPlace;
                airport.IsActive = true;

                if(!string.IsNullOrEmpty(airportBUS.Add(airport)))
                {
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ModelState.AddModelError("", "Have a problem when add new airport, please check and try agian");
                }
            }
            return View();
        }



        // Delete
        public ActionResult Delete(string Id)
        {
            airportBUS.Delete(Id.Trim());
            return RedirectToAction("Index", "Home");
        }
    }
}